Title: Java Scheduling Desktop Application.

Purpose: To schedule appointments for customers across different time zones.

Author: Luis Guillen

Contact information: Phone: (432) 247-2462, E-mail: lguil11@wgu.edu

Student Application Version: 1.1

Date: 8/4/2022

IDE: IntelliJ IDEA Community Edition 2021.3.2

JDk: Java SE 17.0.4

JavaFX: JavaFX-SDK-18.0.1

Instructions to run the program:

- Upon opening the app, the login form will load, the user must input a correct username and password to access the application.
- If login is successful, the user will be alerted if an appointment is within 15 minutes or not. The main form loads. The user
can choose to go to the customers form, appointments form, reports form or exit the application from the main form.
- When accessing the customers form, the user can add, update or delete customers. 
- When accessing the appointments form, the user can add, update or delete customers.
- When accessing the reports form, the user can view appointment schedules by contacts, view the number of appointments by type, month
and by user session.
- When the clicks the exit button, the application is terminated.

Additional report: 

- The user can view the number of appointments booked by user. A text field displays the number of appointments booked with a user
when selecting a user ID from the user combo box. Example: 4 appointments were booked by user 1 ("test") or 2 appointments were booked by 
user 2 ("admin").

MySQL Connector Driver Version: mysql-connector-java-8.0.28
