package controller;

import helper.AppointmentCRUD;
import helper.ListManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointment;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.Month;
import java.util.Optional;
import java.util.ResourceBundle;

/** This class displays the Appointments Form. The user can view, add, update and delete an appointment from this screen.*/
public class AppointmentsForm implements Initializable {

    /** GUI Control for Appointments table view.*/
    @FXML
    public TableView<Appointment> appointmentsTableView;
    /** Table column for the appointment ID.*/
    @FXML
    public TableColumn<Appointment, Integer> appointmentIdCol;
    /** Table column for the appointment title.*/
    @FXML
    public TableColumn<Appointment, String> appointmentTitleCol;
    /** Table column for the appointment description.*/
    @FXML
    public TableColumn<Appointment, String> appointmentDescriptionCol;
    /** Table column for the appointment location.*/
    @FXML
    public TableColumn<Appointment, String> appointmentLocationCol;
    /** Table column for the appointment type.*/
    @FXML
    public TableColumn<Appointment, String> appointmentTypeCol;
    /** Table column for the appointment contact.*/
    @FXML
    public TableColumn<Appointment, Integer> appointmentContactCol;
    /** Table column for the appointment customer ID.*/
    @FXML
    public TableColumn<Appointment, Integer> appointmentCustomerIdCol;
    /** Table column for the appointment user ID.*/
    @FXML
    public TableColumn<Appointment, Integer> appointmentUserIdCol;
    /** Table column for the appointment start date.*/
    @FXML
    public TableColumn<Appointment, Timestamp> appointmentStartDateCol;
    /** Table column for the appointment end date.*/
    @FXML
    public TableColumn<Appointment, Timestamp> appointmentEndDateCol;
    /** GUI Control for the month combo box.*/
    @FXML
    public ComboBox<Month> monthCmb;

    /** List that stores months using enum values.*/
    ObservableList<java.time.Month> allMonths = FXCollections.observableArrayList();

    /**
     * This is the initialize method.
     * This is the first method that is called when the screen associated with this controller gets instantiated.
     * @param url Not used.
     * @param resourceBundle Not used.
     */
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /** Populates the appointments' table view with the all appointments list.*/
        appointmentsTableView.setItems(ListManager.allAppointments);

        /** This statement gets the id from the getId method of every appointment object created.*/
        appointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        /** This statement gets the title from the getTitle method of every appointment object created.*/
        appointmentTitleCol.setCellValueFactory(new PropertyValueFactory<>("title"));

        /** This statement gets the description from the getDescription method of every appointment object created.*/
        appointmentDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));

        /** This statement gets the location from the getLocation method of every appointment object created.*/
        appointmentLocationCol.setCellValueFactory(new PropertyValueFactory<>("location"));

        /** This statement gets the type from the getType method of every appointment object created.*/
        appointmentTypeCol.setCellValueFactory(new PropertyValueFactory<>("type"));

        /** This statement gets the contact from the getContact method of every appointment object created.*/
        appointmentContactCol.setCellValueFactory(new PropertyValueFactory<>("contactId"));

        /** This statement gets the customer ID from the getCustomerId method of every appointment object created.*/
        appointmentCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));

        /** This statement gets the user ID from the getUserId method of every appointment object created.*/
        appointmentUserIdCol.setCellValueFactory(new PropertyValueFactory<>("userId"));

        /** This statement gets the start date from the getStartDate method of every appointment object created.*/
        appointmentStartDateCol.setCellValueFactory(new PropertyValueFactory<>("startDate"));

        /** This statement gets the end date from the getEndDate method of every appointment object created.*/
        appointmentEndDateCol.setCellValueFactory(new PropertyValueFactory<>("endDate"));


        /** Populates the allMonths list with the month.*/
        for(int i = 1; i < 13; i++){

            /** Gets the month and adds it to the allMonths list.*/
            allMonths.add(LocalDate.of(2022, i, 1).getMonth());
        }

        /** Populates the month combo box with the all months list.*/
        monthCmb.setItems(allMonths);

        /** Sets prompt text for the month combo box.*/
        monthCmb.setPromptText("Select Month");
    }

    /**
     * This is the EventHandler for the Main Form button.
     * When the Main Form button is clicked the user is sent to the Main form.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionMainForm(ActionEvent actionEvent) throws IOException {

        /** Displays the main form screen.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
        stage.setTitle("Main Form");
        stage.setScene(new Scene(root, 400, 350));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the EventHandler for the Customers Form button.
     * When the Customers Form button is clicked the user is sent to the Customers form.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionCustomersForm(ActionEvent actionEvent) throws IOException {

        /** Displays the customers form screen.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/CustomersForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
        stage.setTitle("Customers Form");
        stage.setScene(new Scene(root, 1089, 467));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the EventHandler for the Update Appointment button.
     * When the Update Appointment button is clicked the user is sent to the Update Appointment form.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionUpdateAppointment(ActionEvent actionEvent) throws IOException {

        /**Creates a new loader object.*/
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/UpdateAppointment.fxml"));
        loader.load();

        /**Creates a reference variable called UAppointment for the UpdateAppointment class.
         *And loader.getController method gets the Controller associated with the UpdateAppointment.fxml document.
         *UpdateAppointmentController can now be used to access public methods inside the UpdateAppointmentController.*/
        UpdateAppointmentController UAppointment = loader.getController();

        /** Creates a reference variable for the Appointment class and sets it equal to the selected item in the appointmentTableView.*/
        Appointment selectedAppointment = appointmentsTableView.getSelectionModel().getSelectedItem();

        /** Creates a variable and sets it equal to the selected index in the appointment table view.*/
        int selectedIndex = appointmentsTableView.getSelectionModel().getSelectedIndex();

        /** Checks if the user selected an appointment.*/
        if(selectedAppointment != null){

            /**UAppointment is used to access the sendPartData method*/
            UAppointment.sendData(selectedIndex, selectedAppointment);

            /** Loads the update appointment form.*/
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setTitle("Update Appointment Form");
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene, 784, 427));
            stage.setResizable(false); /** Keeps user from resizing the window **/
            stage.show();
        }
        else {

            /** Displays error message if the user did not select an appointment to update.*/
            Alert selectItemError = new Alert(Alert.AlertType.ERROR);
            selectItemError.setTitle("Error Dialog");
            selectItemError.setContentText("Please select an appointment to update.");
            selectItemError.showAndWait();
        }
    }

    /**
     * This is the EventHandler for the select month combo box.
     * It filters appointments by month.
     * @param actionEvent Not used
     * @throws SQLException Throws SQLException if needed
     */
    public void onActionSelectMonth(ActionEvent actionEvent) throws SQLException {

        /** Creates variable that stores the month from selected from the month combo box.*/
        int month = monthCmb.getValue().getValue();

        /** Populates the appointments' table view with a monthly filtered list.*/
        appointmentsTableView.setItems(AppointmentCRUD.selectAppointmentsMonthly(month));
    }

    /**
     * This is the Event Handler for Delete Appointment button.
     * When the Delete Appointment button is clicked it will delete the appointment selected and send the user to the appointments form.
     * @param actionEvent Not used.
     * @throws SQLException Throws SQLException if needed.
     */
    public void onActionDeleteAppointment(ActionEvent actionEvent) throws SQLException {

        /** Creates variable that stores the selected appointment to delete.*/
        Appointment selectedAppointment = appointmentsTableView.getSelectionModel().getSelectedItem();

        /** Checks if the user has selected an appointment.*/
        if (selectedAppointment != null) {

            /** Dialogue box message that confirms whether the appointment is to be deleted or not.*/
            Alert confirmDeletion = new Alert(Alert.AlertType.CONFIRMATION);
            confirmDeletion.setTitle("Appointment Deletion");
            confirmDeletion.setContentText("Are you sure you want to delete this appointment?");

            /** Creates a variable that stores the selection of either the OK or CANCEL button of the dialogue box.*/
            Optional<ButtonType> result = confirmDeletion.showAndWait();

            /** Checks if the user clicks the OK button on the dialogue box.*/
            if (result.isPresent() && result.get() == ButtonType.OK) {

                /** Deletes appointment from the database.*/
                int rowsAffected = AppointmentCRUD.delete(selectedAppointment.getId());

                /** Deletes appointment from the GUI.*/
                if (rowsAffected > 0) {

                    /** Gets the appointment ID from the selected appointment to delete.*/
                    int appointmentID = selectedAppointment.getId();

                    /** Get the appointment type from the selected appointment to delete.*/
                    String appointmentType = selectedAppointment.getType();

                    /** Removes the appointment from the list and consequentially from the appointment table view.*/
                    ListManager.allAppointments.remove(selectedAppointment);

                    /** Displays dialog message with the appointment's ID and Type that will be removed.*/
                    Alert confirmedDeletion = new Alert(Alert.AlertType.INFORMATION);
                    confirmedDeletion.setTitle("Appointment Deletion");
                    confirmedDeletion.setContentText("Appointment ID: " + appointmentID + "\n" +
                            "Appointment Type: " + appointmentType + "\n" +
                            "Appointment deleted successfully.");
                    confirmedDeletion.show();
                }
            }
            else{

                /** Displays dialog message if appointment is not deleted.*/
                Alert confirmedDeletion = new Alert(Alert.AlertType.INFORMATION);
                confirmedDeletion.setTitle("Appointment Deletion");
                confirmedDeletion.setContentText("Appointment was not deleted.");
                confirmedDeletion.show();
            }
        } else {

            /** Displays dialog message if appointment is not deleted.*/
            Alert confirmedDeletion = new Alert(Alert.AlertType.ERROR);
            confirmedDeletion.setTitle("Appointment Deletion");
            confirmedDeletion.setContentText("Please select an appointment to delete.");
            confirmedDeletion.show();
        }
    }

    /**
     * This is the Event Handler for the View All Appointments button.
     * When the View All Appointment button is clicked it displays all the appointments on the appointment table view.
     * @param actionEvent Not used
     */
    public void onActionViewAllAppointments(ActionEvent actionEvent) {

        /** Populates the appointment table view with the all appointments list.*/
        appointmentsTableView.setItems(ListManager.allAppointments);
    }

    /**
     * This is the Event Handler for the View Appointment by Week button.
     * When the View Appointments by Week button is clicked, it displays the appointments within a range of 7 days.
     * @param actionEvent Not used.
     * @throws SQLException Used for SQL exceptions if needed.
     */
    public void onActionViewAppointmentsByWeek(ActionEvent actionEvent) throws SQLException {

        /** Clears the weeklyAppointments list.*/
        ListManager.weeklyFilteredAppointments.clear();

        /** Calls the selectAppointmentsWeekly method.*/
        AppointmentCRUD.selectAppointmentsWeekly();

        /** Populates the appointments' table view with the weeklyFilteredAppoints.*/
        appointmentsTableView.setItems(ListManager.weeklyFilteredAppointments);
    }

    /**
     * This is the Event Handler for the Add Appointment button.
     * When the Add Appointment button is clicked, the user is sent the to Add Appointment form.
     * @param actionEvent Not used
     * @throws IOException Used to handle exceptions if needed.
     */
    public void onActionAddAppointment(ActionEvent actionEvent) throws IOException {

        /** Displays the Add Appointment form.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/AddAppointment.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
        stage.setTitle("Appointments Form");
        stage.setScene(new Scene(root, 784, 467));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }
}

