package controller;

import helper.ListManager;
import helper.ReportsCRUD;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import model.Appointment;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;

/** This class displays the Main Form. The user can navigate to the Customers, Appointments and Reports form. The user can also exit the application.*/
public class MainForm implements Initializable {

    /** GUI Control Button for Customers Form.*/
    @FXML
    public Button customersFormBtn;

    /** GUI Control Button for Appointments Form.*/
    @FXML
    public Button appointmentsFormBtn;

    /** GUI Control Button for Exit.*/
    @FXML
    public Button exitBtn;

    /**
     * This is the initialize method.
     * This is the first method that is called when the screen associated with this controller gets instantiated.
     * @param url Not used
     * @param resourceBundle Not used
     */
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /** Creates variable to help keep count of minutes and initializes it ot 0.*/
        int minutes = 0;

        try {

            /** Minutes variable holds the result of calling the appointmentAlert method.*/
            minutes = ReportsCRUD.appointmentAlert();

            /** Checks if minutes is between 1 and 15.*/
            if(minutes >= 1 && minutes <= 15){

                /** Searches for appointments in the list of upcomingAppointment.*/
                for(Appointment a : ListManager.upcomingAppointment){

                    /** Variable that holds the appointment ID.*/
                    int appointmentID = a.getId();

                    int appointmentUserID = a.getUserId();

                    /** Variable that holds the appointment start date.*/
                    LocalDateTime startDateTime = a.getStartDate();

                    /** Variable that helps to format date and time.*/
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM-dd-YY h:mm a");

                    /** Displays message if an appointment is found to be within 15 minutes.*/
                    Alert appointmentAlert = new Alert(Alert.AlertType.INFORMATION);
                    appointmentAlert.setTitle("Appointment Alert");
                    appointmentAlert.setContentText("You have an appointment in approximately: " + minutes + " minute(s)!" + "\n\n" +
                                                    "Appointment ID: " + appointmentID + "\n"+
                                                    "Date/Time: " + dtf.format(startDateTime) + "\n" +
                                                    "User ID: " + appointmentUserID);
                    appointmentAlert.showAndWait();
                    break;
                }
            }else{

                /** Displays message if an appointment is not found within 15 minutes.*/
                Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
                confirmAddition.setTitle("Appointment Alert");
                confirmAddition.setContentText("There are no upcoming appointments.");
                confirmAddition.showAndWait();
            }
        } catch (SQLException e) {
           // e.printStackTrace();
        }
    }

    /**
     * This is the EventHandler for the Customers Form button.
     * When the Customers Form button is clicked the user is sent to the Customers form.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionCustomersForm(ActionEvent actionEvent) throws IOException {

        /** Loads the Customers Form screen.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/CustomersForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
        stage.setTitle("Customers Form");
        stage.setScene(new Scene(root, 1089, 467));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the Event Handler for the Appointments Form button.
     * When the Appointments Form button is clicked the user is sent to the Appointments form.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionAppointmentsForm(ActionEvent actionEvent) throws IOException {

        /** Loads the Appointments Form screen.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/AppointmentsForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
        stage.setTitle("Appointments Form");
        stage.setScene(new Scene(root, 1360, 467));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the Event Handler for the Exit button.
     * When the Exit button is clicked, the application is terminated.
     * @param actionEvent Not used.
     */
    public void onActionExit(ActionEvent actionEvent) {

        /** Alert dialogue box that confirms exit.*/
        Alert onExit = new Alert(Alert.AlertType.CONFIRMATION);
        onExit.setTitle("Exit Application");
        onExit.setContentText("Are you sure you want to exit the application?");
        Optional<ButtonType> result = onExit.showAndWait();

        /** Terminates the application if the user clicks Ok in the dialogue box.*/
        if(result.isPresent() && result.get() == ButtonType.OK)
            System.exit(0);
    }

    /**
     * This is the Event Handler for the Reports button.
     * When the Reports button is clicked the user is sent to the Reports Form.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionReports(ActionEvent actionEvent) throws IOException {

        /** Loads the Reports Form screen.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/ReportsForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
        stage.setTitle("Reports Form");
        stage.setScene(new Scene(root, 1200, 625));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }
}
