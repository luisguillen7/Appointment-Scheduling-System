package controller;

import expressions.UserLogin;
import helper.ListManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import expressions.MyZoneId;
import model.User;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/** This class displays the Login Form. The user logins into the application through this screen.*/
public class LoginForm implements Initializable {

    /** GUI Control Label for Location.*/
    @FXML
    public Label locationLbl;

    /** GUI Control for the login button.*/
    @FXML
    public Button loginBtn;

    /** GUI Control for the username text field.*/
    @FXML
    public TextField userNameTxt;

    /** GUI Control for the password text field.*/
    @FXML
    public TextField passwordTxt;

    /** GUI Control for the username label.*/
    @FXML
    public Label usernameLbl;

    /** GUI Control for the password label.*/
    @FXML
    public Label passwordLbl;

    /** Creates a resource bundle reference.*/
    ResourceBundle rb;

    /**
     * This is the initialized method.
     * This is the first method that is called when the screen associated with this controller gets instantiated.
     * @param url Not used.
     * @param resourceBundle Used to get the translations for the program.
     */
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try{

            /** Retrieves the resource bundle file according to the default language set on the user's system.
             * This allows to translate the program to the language in which the user's computer operates.*/
             rb = ResourceBundle.getBundle("resourcebundle/Nat", Locale.getDefault());

             /** Sets the text for the labels and uses the resource bundle for translating the labels.*/
            usernameLbl.setText(rb.getString("Username") + ":");
            passwordLbl.setText(rb.getString("Password") + ":");

            /** Sets the text for the login button and uses the resource bundle for translating the button.*/
            loginBtn.setText(rb.getString("Login"));

        }/** Catches an exception in case a resource bundle is not found.*/
        catch(MissingResourceException e) {
            System.out.print(e.getMessage() + "\n");

            //Locale.getDefault().getLanguage().equals("us");
        }

        /** LAMBDA EXPRESSION.*/

        /** This lambda expression displays the zone in which the user's computer operates. The location label sets its text to display the
         * zone by getting the user's system default.*/
        MyZoneId myZoneId = () -> String.valueOf(ZoneId.systemDefault());
        locationLbl.setText(myZoneId.getMyZoneId());
    }

    /**
     * This is the EventHandler for the Login Button.
     * When the Login button is clicked the user is sent to the main form.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionLogin(ActionEvent actionEvent) throws IOException {

        /** Create filename variable.*/
        String filename = "login_activity.txt";

        /** Creates variable to help detect when username and password are correct.*/
        boolean match = false;

        /** String variables that store the username and password retrieved from the text fields.*/
        String userName = userNameTxt.getText();
        String password = passwordTxt.getText();

        /** Creates file writer object that allows to write character-oriented data to a file.
         * Append is set to true in order to allow data to remain in the file and to not be overwritten.*/
        FileWriter fileWriter = new FileWriter(filename, true);

        /** Creates print writer object that allows to write different types of data to a file.*/
        PrintWriter outputFile = new PrintWriter(fileWriter);

        try {

            /** Check if username and password text-fields are not empty.*/
            if (!userName.isBlank() && !password.isBlank()) {

                /** Loop that checks if a user is found within the list of users in the databases.*/
                for (User a : ListManager.allUsers) {

                    /** Checks if the username and the password entered matches any username and password from the database.*/
                    if (a.getUsername().equals(userName) && a.getPassword().equals(password)) {
                        match = true;
                        break;
                    }
                }

                /** LAMBDA EXPRESSION*/

                /** This lambda expression takes in parameters that will help print the username, password, timestamp and status of the login
                 * to the login_activity file.*/
                UserLogin ul = (u, p, t, s) -> {

                    /** Prints username to the file using a parameter from the lambda expression.*/
                    outputFile.println("Username: " + u);

                    /** Prints password to the file using a parameter from the lambda expression.*/
                    outputFile.println("Password: " + p);

                    /** Prints date and time of login to the file using a parameter from the lambda expression.*/
                    outputFile.println("Date of login: " + t);

                    /** Prints status to the file using a parameter from the lambda expression.*/
                    outputFile.println("Status: " + s + "\n");
                };

                    /** Checks if match is true.*/
                    if (match) {

                        /** Displays the main form screen.*/
                        Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
                        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                        stage.setTitle("Main Form");
                        stage.setScene(new Scene(root, 400, 350));
                        stage.setResizable(false); /** Keeps user from resizing the window **/
                        stage.show();

                        /** Lambda expression executes when the username and password entered are correct.
                         * The lambda expression passes the username, password, timestamp and the login status is set to
                         * display it was successful.*/
                        ul.userLogin(userName, password, LocalDateTime.now(), "Login Successful");

                        /** Closes the file.*/
                        outputFile.close();

                    } else {

                        /** Displays message if login is unsuccessful.*/
                        Alert loginConfirmation = new Alert(Alert.AlertType.INFORMATION);

                        /** Uses resource bundle to determine the language of the dialogue box title.*/
                        loginConfirmation.setTitle(rb.getString("Login"));

                        /** Uses resource bundle to determine the language of the dialogue box message.*/
                        loginConfirmation.setContentText(rb.getString("Invalid") + " " +  rb.getString("username") + " " + rb.getString("or") + " " + rb.getString("password") + "!");
                        loginConfirmation.showAndWait();

                        /** Lambda expression executes when the username and password entered are incorrect.
                         * The lambda expression passes the username, password, timestamp and the login status is set to
                         * display it was unsuccessful.*/
                        ul.userLogin(userName, password, LocalDateTime.now(), "Login Unsuccessful");

                        /** Closes file.*/
                        outputFile.close();
                    }
            } else {
                /** Displays message if user does not enter a username or password.*/
                Alert loginConfirmation = new Alert(Alert.AlertType.INFORMATION);

                /** Uses resource bundle to determine the language of the dialogue box title.*/
                loginConfirmation.setTitle(rb.getString("Login"));

               /** Uses resource bundle to determine the language of the dialogue box message.*/
                loginConfirmation.setContentText(rb.getString("Please")+  " " + rb.getString("enter") + " " + rb.getString("username") + " " + rb.getString("and") + " " + rb.getString("password") + "!");
                loginConfirmation.showAndWait();
            }
        }

        /** Catches exception if a resource bundle is not found.*/
        catch(MissingResourceException e){
        }
    }
}
