package controller;

import helper.AppointmentCRUD;
import helper.ListManager;
import helper.TimeManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.*;
import java.util.ResourceBundle;

/** This class displays the Add Appointment Form. The user can add an appointment from this screen.*/
public class AddAppointment implements Initializable {

    /** GUI Control for the contact combo box.*/
    @FXML
    public ComboBox<Contact> contactComboBox;
    /** GUI Control for the user combo box.*/
    @FXML
    public ComboBox<User> userComboBox;
    /** GUI Control for the type combo box.*/
    @FXML
    public ComboBox<String> typeComboBox;
    /** GUI Control for the appointment ID text field.*/
    @FXML
    public TextField appointmentIDTxt;
    /** GUI Control for the appointment title text field.*/
    @FXML
    public TextField appointmentTitleTxt;
    /** GUI Control for the appointment description text field.*/
    @FXML
    public TextField appointmentDescriptionTxt;
    /** GUI Control for the appointment location text field.*/
    @FXML
    public TextField appointmentLocationTxt;
    /** GUI Control for the appointment Start Date, date picker.*/
    @FXML
    public DatePicker appointmentStartDatePicker;
    /** GUI Control for the appointment End Date, date picker.*/
    @FXML
    public DatePicker appointmentEndDatePicker;
    /** GUI Control for the appointment Start Time, combo box.*/
    @FXML
    public ComboBox<LocalTime> startTimeCmb;
    /** GUI Control for the appointment End Time, combo box.*/
    @FXML
    public ComboBox<LocalTime> endTimeCmb;
    /** GUI Control for the appointment customer ID combo box.*/
    @FXML
    public ComboBox<Customer> customerIDComboBox;

    /** Index used for send data method.*/
    private int index;

    /**
     * This is the initialize method.
     * This is the first method that is called when the screen associated with this controller gets instantiated.
     * @param url Not used.
     * @param resourceBundle Not used.
     */
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /** ADD APPOINTMENT FORM COMBO BOXES.*/

        /** Sets prompt text for the contact combo box.*/
        contactComboBox.setPromptText("Select Contact");

        /** Populates the contact combo box with allContacts list.*/
        contactComboBox.setItems(ListManager.allContacts);

        /** Populates the contact combo box with allCustomers list.*/
        customerIDComboBox.setItems(ListManager.allCustomers);

        /** Sets prompt text for the contact user combo box.*/
        customerIDComboBox.setPromptText("Select Customer");

        /** Sets prompt text for the contact user combo box.*/
        userComboBox.setPromptText("Select User");

        /** Populates the user combo box with allUsers list.*/
        userComboBox.setItems(ListManager.allUsers);

        /** Sets prompt text for the type user combo box.*/
        typeComboBox.setPromptText("Select Type");

        /** Populates the type combo box with allTypes list.*/
        typeComboBox.setItems(ListManager.allTypes);

        /** Sets the hour list for the Start Time ComboBox*/
        startTimeCmb.setItems(TimeManager.generateTimes(0, 24));

        /** Selects the first hour from the Start Time combo box.*/
        startTimeCmb.getSelectionModel().selectFirst();

        /** Sets the hour list for the End Time ComboBox*/
        endTimeCmb.setItems(TimeManager.generateTimes(1, 24));

        /** ASK ABOUT THIS ONE*/
        endTimeCmb.getItems().add(LocalTime.of(0, 0));

        /** Selects the first hour from the time observable list.*/
        endTimeCmb.getSelectionModel().selectFirst();
    }


    /**
     * This is the EventHandler for the Save button.
     * When the Save button is clicked the user is sent to the Appointments form and adds a new appointment to the table.
     * @param actionEvent Not Used.
     * @throws IOException To handle code failures if needed.
     */
    @FXML
    public void onActionSave(ActionEvent actionEvent) throws IOException, SQLException {

        try{

            /** Creates variables that hold the data that the user entered to the several GUI controls.*/
            String title = appointmentTitleTxt.getText();
            String description = appointmentDescriptionTxt.getText();
            String location = appointmentLocationTxt.getText();
            String type = String.valueOf(typeComboBox.getValue());
            int contact = contactComboBox.getValue().getId();
            int customerId = customerIDComboBox.getValue().getId();
            int userId = userComboBox.getValue().getId();

            /** Get input from the DatePicker widgets.*/
            LocalDate startDate = appointmentStartDatePicker.getValue();
            LocalDate endDate = appointmentEndDatePicker.getValue();

            /** Get input from the StartTime ComboBox.*/
            LocalTime startTime = startTimeCmb.getValue();

            /** Get input from the EndTime ComboBox.*/
            LocalTime endTime = endTimeCmb.getValue();

            /** Combines data from DatePickers and combo boxes that stores time lists.*/
            LocalDateTime startDateTime = LocalDateTime.of(startDate, startTime);
            LocalDateTime endDateTime = LocalDateTime.of(endDate, endTime);

            /** Variable that gets the system default time zone.*/
            ZoneId localZone = ZoneId.systemDefault();

            /** Variable that stores the eastern time zone.*/
            ZoneId eastern = ZoneId.of("America/New_York");

            /** Convert to system default.*/
            ZonedDateTime localStartZDT = startDateTime.atZone(localZone);

           /** Convert to Eastern Time.*/
           ZonedDateTime easternStartZDT = localStartZDT.withZoneSameInstant(eastern);

           /** Get a LocalDateTime.*/
           LocalDateTime easternStartDateTime = easternStartZDT.toLocalDateTime();

           /** Set the business hours requirements.*/
           LocalTime bStart = LocalTime.of(8, 0);
           LocalTime bEnd = LocalTime.of(22,0);

           /** Validate if the eastern selected time is within business hours.*/
           if(easternStartDateTime.toLocalTime().isBefore(bStart) || easternStartDateTime.toLocalTime().isAfter(bEnd)){

               /** Displays alert message if the appointment is not within business hours.*/
               Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
               confirmAddition.setTitle("Appointment");
               confirmAddition.setContentText("Appointment is not within business hours.");
               confirmAddition.showAndWait();
              return;
           }

           /** For loop that searches for an appointment in the list of appointments.*/
               for(Appointment a : ListManager.allAppointments){

                   /** Checks if the customer's appointment doesn't match the customer ID from the text field.*/
                   if(a.getCustomerId() != customerId) {
                       continue;
                   }

                   /** Checks if the start time of an appointment overlaps another appointment by starting before the other one is finished or starts at the same time.*/
                   if(a.getStartDate().isAfter(startDateTime) || a.getStartDate().isEqual(startDateTime) && a.getStartDate().isBefore(endDateTime)){

                       /** Displays alert message if appointment collides.*/
                       Alert alertCollision = new Alert(Alert.AlertType.INFORMATION);
                       alertCollision.setTitle("Appointment");
                       alertCollision.setContentText("Appointment collides!");
                       alertCollision.showAndWait();
                       return;
                   }

                   /** Checks if an appointment ends in the middle of an ongoing appointment.*/
                   if(a.getEndDate().isAfter(startDateTime) && a.getEndDate().isBefore(endDateTime)){

                       /** Displays alert message if appointment collides.*/
                       Alert alertCollision = new Alert(Alert.AlertType.INFORMATION);
                       alertCollision.setTitle("Appointment");
                       alertCollision.setContentText("Appointment collides!");
                       alertCollision.showAndWait();
                       return;
                   }

                   /** Checks if an appointment starts before an ongoing appointment and ends after the ongoing appointment finishes.*/
                   if(a.getStartDate().isBefore(startDateTime) && a.getEndDate().isAfter(endDateTime)){

                       /** Displays alert message if appointment collides.*/
                       Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
                       confirmAddition.setTitle("Appointment");
                       confirmAddition.setContentText("Appointment collides!");
                       confirmAddition.showAndWait();
                       return;
                   }
               }

               /** Checks for empty text fields and no item selected from the combo boxes.*/
               if(!title.isEmpty() && !description.isEmpty() && !location.isEmpty() && !contactComboBox.getSelectionModel().isEmpty() && !customerIDComboBox.getSelectionModel().isEmpty()
                  && !userComboBox.getSelectionModel().isEmpty() && !startTimeCmb.getSelectionModel().isEmpty() && !typeComboBox.getSelectionModel().isEmpty()){

                   /** Calls the method that inserts appointments into the database.*/
                   int rowsAffected = AppointmentCRUD.insert(title, description, location, type, contact, customerId, userId, startDateTime, endDateTime);

                   /** Checks if rowsAffected is greater than 0.*/
                   if(rowsAffected > 0){

                       /** Adds new appointment to the table view (GUI).*/
                       int appointmentId = AppointmentCRUD.getMaxId();
                       Appointment a = new Appointment(appointmentId, title, description, location , type, startDateTime, endDateTime, customerId, userId, contact);
                       ListManager.allAppointments.add(a);

                       /** Displays message if appointment is added successfully.*/
                       Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
                       confirmAddition.setTitle("Appointment");
                       confirmAddition.setContentText("Appointment added successfully!");
                       confirmAddition.showAndWait();
                   }
                   else{

                       /** Displays message if appointment is not added.*/
                       Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
                       confirmAddition.setTitle("Appointment");
                       confirmAddition.setContentText("Appointment not added.");
                       confirmAddition.showAndWait();
                   }
               }
               else{

                   /** Displays message if appointment is not added.*/
                   Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
                   confirmAddition.setTitle("Appointment");
                   confirmAddition.setContentText("Please enter or select data in the missing fields.");
                   confirmAddition.showAndWait();
                   return;
               }

        }catch (Exception e){

            /** Displays an error message in case the GUI input fields are empty.*/
            Alert inputDataError = new Alert(Alert.AlertType.INFORMATION);
            inputDataError.setTitle("Appointment");
            inputDataError.setContentText("Please enter values for the fields.");
            inputDataError.showAndWait();
            return;
        }

        /** Loads the Appointments Form screen.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/AppointmentsForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setTitle("Appointments Form");
        stage.setScene(new Scene(root, 1360, 467));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the EventHandler for the Cancel button.
     * When the Cancel button is clicked the user is sent to the Appointments form and does not add a new appointment to the table.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionCancel(ActionEvent actionEvent) throws IOException {

        /** Displays message if an appointment was not added.*/
        Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
        confirmAddition.setTitle("Appointment");
        confirmAddition.setContentText("Appointment was not added.");
        confirmAddition.showAndWait();

        /** Loads the Appointments Form screen.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/AppointmentsForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
        stage.setTitle("Appointments Form");
        stage.setScene(new Scene(root, 1360, 467));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the EventHandler for the Start Time combo box.
     * It selects an hour for the End Time combo box when the user selects an hour from the Start Time combo box.
     * @param actionEvent actionEvent is not used.
     */
    public void onActionSelectStartTime(ActionEvent actionEvent) {

        /** Gets the start time (hour) from the start time combo box and stores it in an int.*/
        int hour = startTimeCmb.getValue().getHour();

        /** Populates the End Time combo box starting an hour ahead of the start time using the generateTimes method.*/
        endTimeCmb.setItems(TimeManager.generateTimes(hour+1, 24));
        endTimeCmb.getItems().add(LocalTime.of(0, 0));

        /** Sets the End Time combo box to select the first hour from the list.*/
        endTimeCmb.getSelectionModel().selectFirst();
    }

    /**
     * This is the Event Handler for the Start Date Picker widget.
     * When the user chooses a Start date, it sets the EndDate DatePicker to the same day automatically.
     * @param actionEvent actionEvent not used.
     */
    public void onActionSelectStartDate(ActionEvent actionEvent) {

        /** Sets the EndDate DatePicker to the same date chosen from the StartDate Picker.*/
        appointmentEndDatePicker.setValue(appointmentStartDatePicker.getValue());
    }
}
