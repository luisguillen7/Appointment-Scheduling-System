package controller;

import helper.CustomerCRUD;
import helper.ListManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Country;
import model.Customer;
import model.FirstLevelDivision;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

/** This class displays the Update Customer form. The user can update data of a previous customer created.*/
public class UpdateCustomer implements Initializable {

    /** GUI Control for the update ID text field.*/
    @FXML
    public TextField updateId;

    /** GUI Control for the update name text field.*/
    @FXML
    public TextField updateName;

    /** GUI Control for the update address text field.*/
    @FXML
    public TextField updateAddress;

    /** GUI Control for the update postal code text field.*/
    @FXML
    public TextField updatePostalCode;

    /** GUI Control for the update phone number text field.*/
    @FXML
    public TextField updatePhoneNumber;

    /** GUI Control for the country combo box.*/
    @FXML
    public ComboBox<Country> countryComboBox;

    /** GUI Control for the first level division combo box.*/
    @FXML
    public ComboBox<FirstLevelDivision> firstLevelDivisionComboBox;

    /** Data that is not retrieved from GUI controls. */
    public LocalDateTime lastUpdate = LocalDateTime.now();
    String createdBy = "Luis";
    String lastUpdatedBy = "Luis";

    /** Defines a variable of type int that will be passed to sendPartData.*/
    private int index;

    /** List that holds the correspondent first-level divisions of their respective countries.*/
    ObservableList<FirstLevelDivision> filteredDivisions = FXCollections.observableArrayList();

    /**
     * This is the initialized method.
     * This is the first method that is called when the screen associated with this controller gets instantiated.
     * @param url Not used.
     * @param resourceBundle Not used.
     */
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    /** This is the sendData method.
     * This method sends appointment data across controllers.
     * @param index The index of the array list.
     * @param customer A customer object.
     */
    public void sendData(int index, Customer customer){

        /** Populates the country combo box with a list of countries. (US, UK and Canada).*/
        countryComboBox.setItems(ListManager.allCountries);

        this.index = index;

        /** Retrieves and sets customer data on the GUI fields.*/
        updateId.setText(String.valueOf(customer.getId()));
        updateName.setText(customer.getName());
        updateAddress.setText(customer.getAddress());
        updatePostalCode.setText(customer.getPostalCode());
        updatePhoneNumber.setText(customer.getPhone());

        /** Searches for a country in the allCountries list.*/
        for(Country c : ListManager.allCountries){

            /** Checks if the country's ID matches the customer's country ID.*/
            if(c.getCountryId() == customer.getCountryId()){

                /** Sets the country combo box with the country that matches the customer's country.*/
                countryComboBox.setValue(c);
                break;
            }
        }

     /** Creates variable that stores the country id from the country selected from the combo box.*/
        int countryId = countryComboBox.getValue().getCountryId();

        /** Searches for a division within the allDivisions list.*/
        for(FirstLevelDivision f : ListManager.allDivisions){

            /** Checks if the division's country id matches the country's id from the country selected.*/
            if(f.getCountryId() == countryId){

                /** Adds the division to the filtered divisions list.*/
                filteredDivisions.add(f);
            }
        }

        /** Populates First Level Division ComboBox.*/
        firstLevelDivisionComboBox.setItems(filteredDivisions);

        /** Searches for a first level division in the filteredDivisions list.*/
        for(FirstLevelDivision f : filteredDivisions){

            /** Checks if the first level division's ID matches the customer's first level division.*/
            if(f.getDivisionId() == customer.getDivisionId()){

                /** Sets the first level division combo box with the matching customer first level division.*/
                firstLevelDivisionComboBox.setValue(f);
                break;
            }
        }
    }

    /**
     * This is the EventHandler for the Save button.
     * When the Save button is clicked the user is sent to the Customers form and updates the customer selected.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionSave(ActionEvent actionEvent) throws IOException, SQLException {

        /** Get the data from the TextFields. */
        int customerId = Integer.parseInt(updateId.getText());
        String name = updateName.getText();
        String address = updateAddress.getText();
        String postalCode = updatePostalCode.getText();
        String phone = updatePhoneNumber.getText();

        /** These string variables are used to display info on the GUI.*/
        String firstLevelDivision = String.valueOf(firstLevelDivisionComboBox.getValue());
        String country = String.valueOf(countryComboBox.getValue());

        /** These int variables are used to pass info into the database.*/
        int firstLevelDivisionId = firstLevelDivisionComboBox.getValue().getDivisionId();
        int countryId = countryComboBox.getValue().getCountryId();


        /** Checks if the text fields are not empty.*/
        if(!name.isEmpty() && !address.isEmpty() && !postalCode.isEmpty() && !phone.isEmpty()) {

            /** Updates the data of a customer in the database.*/
            int rowsAffected = CustomerCRUD.update(customerId, name, address, postalCode, phone, createdBy, firstLevelDivisionId);

            if (rowsAffected > 0) {

                /** Creates a new customer object and is passed the data retrieved from the textFields and comboBoxes*/
                Customer c = new Customer(customerId, name, address, postalCode, phone, firstLevelDivision, country, firstLevelDivisionId, countryId);

                /** Updates the customer and changes are reflected in the GUI.*/
                ListManager.allCustomers.set(index, c);

                /** Displays message if customer is updated successfully.*/
                Alert confirmUpdate = new Alert(Alert.AlertType.INFORMATION);
                confirmUpdate.setTitle("Customer");
                confirmUpdate.setContentText("Customer updated successfully!");
                confirmUpdate.showAndWait();
            }
            else{

                /** Displays message if customer is not updated.*/
                Alert confirmUpdate = new Alert(Alert.AlertType.INFORMATION);
                confirmUpdate.setTitle("Customer");
                confirmUpdate.setContentText("Customer was not updated.");
                confirmUpdate.showAndWait();
            }

            /** Loads the Customers Form.*/
            Parent root = FXMLLoader.load(getClass().getResource("/view/CustomersForm.fxml"));
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
            stage.setTitle("Appointments Form");
            stage.setScene(new Scene(root, 1089, 467));
            stage.setResizable(false); /** Keeps user from resizing the window **/
            stage.show();

        }
        /** Checks if the name text field is empty.*/
        else if(name.isEmpty()){
            Alert checkField = new Alert(Alert.AlertType.INFORMATION);
            checkField.setTitle("Customer");
            checkField.setContentText("Please enter a valid name.");
            checkField.showAndWait();
        }
        /** Checks if the address field is empty.*/
        else if(address.isEmpty()){
            Alert checkField = new Alert(Alert.AlertType.INFORMATION);
            checkField.setTitle("Customer");
            checkField.setContentText("Please enter a valid address.");
            checkField.showAndWait();
        }
        /** Checks if the postal code field is empty.*/
        else if(postalCode.isEmpty()){
            Alert checkField = new Alert(Alert.AlertType.INFORMATION);
            checkField.setTitle("Customer");
            checkField.setContentText("Please enter a valid postal code.");
            checkField.showAndWait();
        }
        /** Checks if the phone field is empty.*/
        else if(phone.isEmpty()){
            Alert checkField = new Alert(Alert.AlertType.INFORMATION);
            checkField.setTitle("Customer");
            checkField.setContentText("Please enter a valid phone.");
            checkField.showAndWait();
        }
    }

    /**
     * This is the EventHandler for the Cancel button.
     * When the Cancel button is clicked the user is sent to the Customers form and does not update the customer selected.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionCancel(ActionEvent actionEvent) throws IOException {

        /** Displays message if customer was not updated.*/
        Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
        confirmAddition.setTitle("Update Customer");
        confirmAddition.setContentText("Customer was not updated.");
        confirmAddition.showAndWait();


        /** Loads the Customers Form.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/CustomersForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
        stage.setTitle("Appointments Form");
        stage.setScene(new Scene(root, 1089, 467));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the Event Handler for the Select Country combo box.
     * When the user selects a country, the first level division combo box is populated with the correspondent divisions that pertain to that country.
     * @param actionEvent Not used.
     */
    public void onActionSelectCountry(ActionEvent actionEvent) {

        /** Clears the filteredDivisions list.*/
        filteredDivisions.clear();

        /** Creates variable that holds the ID of the country selected.*/
        int countryID = countryComboBox.getValue().getCountryId();

        /** Searches for a first level division in the allDivisions list.*/
        for(FirstLevelDivision f : ListManager.allDivisions){

            /** Checks if the first level division's ID matches the selected country's ID.*/
            if(f.getCountryId() == countryID){

                /** Adds all the matching ID's of the filtered divisions to the filteredDivisions list.*/
                filteredDivisions.add(f);
            }
        }

        /** Populates the first level division combo box with the filteredDivisions list.*/
        firstLevelDivisionComboBox.setItems(filteredDivisions);

        /** Selects the first item of the combo box.*/
        firstLevelDivisionComboBox.getSelectionModel().selectFirst();
    }
}

