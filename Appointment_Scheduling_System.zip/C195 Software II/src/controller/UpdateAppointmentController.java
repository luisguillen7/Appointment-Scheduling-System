package controller;

import helper.AppointmentCRUD;
import helper.ListManager;
import helper.TimeManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Appointment;
import model.Contact;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.*;
import java.util.ResourceBundle;

/** This class displays the Update Appointment form. The user can update data of a previous appointment created.*/
public class UpdateAppointmentController implements Initializable {

    /** GUI Control for the appointment ID text field.*/
    @FXML
    public TextField appointmentIDTxt;

    /** GUI Control for the title text field.*/
    @FXML
    public TextField titleTxt;

    /** GUI Control for the description text field.*/
    @FXML
    public TextField descriptionTxt;

    /** GUI Control for the location text field.*/
    @FXML
    public TextField locationTxt;

    /** GUI Control for the contact combo box.*/
    @FXML
    public ComboBox<Contact> contactCmb;

    /** GUI Control for the customer ID text field.*/
    @FXML
    public TextField customerIDTxt;

    /** GUI Control for the user combo box.*/
    @FXML
    public ComboBox<User> userIDCmb;

    /** GUI Control for the start date picker.*/
    @FXML
    public DatePicker startDatePicker;

    /** GUI Control for the end date picker.*/
    @FXML
    public DatePicker endDatePicker;

    /** GUI Control for the start time combo box.*/
    @FXML
    public ComboBox<LocalTime> startTimeCmb;

    /** GUI Control end time combo box.*/
    @FXML
    public ComboBox<LocalTime> endTimeCmb;

    /** GUI Control for the type combo box.*/
    @FXML
    public ComboBox<String> typeCmb;

    /** Defines a variable of type int that will be passed to sendPartData.*/
    private int index;

    /**
     * This is the initialize method.
     * This is the first method that is called when the screen associated with this controller gets instantiated.
     * @param url Not used.
     * @param resourceBundle Not used.
     */
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /** Sets the prompt text for the contact combo box.*/
        contactCmb.setPromptText("Select Contact");

        /** Populates the contact combo box with the allContacts list.*/
        contactCmb.setItems(ListManager.allContacts);

        /** Sets the prompt text for the user combo box.*/
        userIDCmb.setPromptText("Select User");

        /** Populates the user combo box with the allUsers list.*/
        userIDCmb.setItems(ListManager.allUsers);

        /** Sets the prompt text for the type combo box.*/
        typeCmb.setPromptText("Select Type");

        /** Populates the type combo box with the allTypes list.*/
        typeCmb.setItems(ListManager.allTypes);

        /** Sets the hour list for the Start Time combo box.*/
        startTimeCmb.setItems(TimeManager.generateTimes(0, 24));

        /** Selects the first hour from the time observable list*/
        startTimeCmb.getSelectionModel().selectFirst();

        /** Sets the hour list for the End Time combo box.*/
        endTimeCmb.setItems(TimeManager.generateTimes(1, 24));
        endTimeCmb.getItems().add(LocalTime.of(0, 0));

        /** Selects the first hour from the time observable list**/
        endTimeCmb.getSelectionModel().selectFirst();
    }

    /**
     * This is the sendData method.
     * This method sends appointment data across controllers.
     * @param index The index of the array list.
     * @param appointment An appointment object.
     */
    public void sendData(int index, Appointment appointment){

        this.index = index;

        /** Sets the data for the appointment text fields.*/
        appointmentIDTxt.setText(String.valueOf(appointment.getId()));
        titleTxt.setText(appointment.getTitle());
        descriptionTxt.setText(appointment.getDescription());
        locationTxt.setText(appointment.getLocation());
        customerIDTxt.setText(String.valueOf(appointment.getCustomerId()));

        /** Sets the data for the date pickers.*/
        startDatePicker.setValue(appointment.getStartDate().toLocalDate());
        endDatePicker.setValue(appointment.getEndDate().toLocalDate());

        /** Sets the data for the start and end times combo boxes.*/
        startTimeCmb.setValue(appointment.getStartDate().toLocalTime());
        endTimeCmb.setValue(appointment.getEndDate().toLocalTime());

        /** Sets the data for the type combo box.*/
        typeCmb.setValue(appointment.getType());

        /** Searches for a contact in the allContacts list.*/
        for(Contact c : ListManager.allContacts){

            /** Checks if the contact searched for matches the contact ID of the appointment.*/
            if(c.getId() == appointment.getContactId()){

                /** Selects the contact with matching IDs.*/
                contactCmb.getSelectionModel().select(c);
                break;
            }
        }

        /** Searches for a user in the allUsers list.*/
        for(User u : ListManager.allUsers){

            /** Checks if the user searched for matches the user ID of the appointment.*/
            if(u.getId() == appointment.getUserId()){

                /** Selects the user with matching IDs.*/
                userIDCmb.getSelectionModel().select(u);
                break;
            }
        }
    }

    /**
     * This is the EventHandler for the Save button.
     * When the Save button is clicked the user is sent to the Appointments form and updates the appointment selected.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public void onActionSave(ActionEvent actionEvent) throws IOException, SQLException {


        try {

            /** Get the data from the text fields*/
            int appointmentId = Integer.parseInt(appointmentIDTxt.getText());
            int customerId = Integer.parseInt(customerIDTxt.getText());
            String title = titleTxt.getText();
            String description = descriptionTxt.getText();
            String location = locationTxt.getText();

            /** Get data from the combo boxes*/
            int contactId = contactCmb.getValue().getId();
            int userId = userIDCmb.getValue().getId();
            String type = typeCmb.getValue();
            LocalTime startTime = startTimeCmb.getValue();
            LocalTime endTime = endTimeCmb.getValue();

            /** Gets the data from the date pickers.*/
            LocalDate startDate = startDatePicker.getValue();
            LocalDate endDate = endDatePicker.getValue();

            /** Combines the date picker data and the time combo boxes data.*/
            LocalDateTime startDateTime = LocalDateTime.of(startDate, startTime);
            LocalDateTime endDateTime = LocalDateTime.of(endDate, endTime);

            /** Variable that gets the system default time zone.*/
            ZoneId localZone = ZoneId.systemDefault();

            /** Variable that stores the eastern time zone.*/
            ZoneId eastern = ZoneId.of("America/New_York");

            /** Convert startDateTime to the local zone system default.*/
            ZonedDateTime localStartZDT = startDateTime.atZone(localZone);

            /** Convert startDateTime to the zone Eastern Time.*/
            ZonedDateTime easternStartZDT = localStartZDT.withZoneSameInstant(eastern);

            /** Get a LocalDateTime.*/
            LocalDateTime easternStartDateTime = easternStartZDT.toLocalDateTime();

            /** Set the business hours requirements.*/
            LocalTime bStart = LocalTime.of(8, 0);
            LocalTime bEnd = LocalTime.of(22, 0);

            /** Validate if the eastern selected time is within business hours.*/
            if (easternStartDateTime.toLocalTime().isBefore(bStart) || easternStartDateTime.toLocalTime().isAfter(bEnd)) {

                /** Displays alert message if the appointment is not within business hours.*/
                Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
                confirmAddition.setTitle("Appointment");
                confirmAddition.setContentText("Appointment is not within business hours.");
                confirmAddition.showAndWait();
                return;
            }

            /** For loop that searches for an appointment in the list of appointments.*/
            for (Appointment a : ListManager.allAppointments) {

                /** Checks if the customer's appointment doesn't match the customer ID from the text field.*/
                if (a.getCustomerId() != customerId) {
                    continue;
                }

                /** Checks if the start time of an appointment overlaps another appointment by starting before the other one is finished or starts at the same time.*/
                if (a.getStartDate().isAfter(startDateTime) && a.getStartDate().isBefore(endDateTime)) {

                    /** Displays alert message if appointment collides.*/
                    Alert alertCollision = new Alert(Alert.AlertType.INFORMATION);
                    alertCollision.setTitle("Appointment");
                    alertCollision.setContentText("Appointment collides!");
                    alertCollision.showAndWait();
                    return;
                }

                /** Checks if an appointment ends in the middle of an ongoing appointment.*/
                if (a.getEndDate().isAfter(startDateTime) && a.getEndDate().isBefore(endDateTime)) {

                    /** Displays alert message if appointment collides.*/
                    Alert alertCollision = new Alert(Alert.AlertType.INFORMATION);
                    alertCollision.setTitle("Appointment");
                    alertCollision.setContentText("Appointment collides!");
                    alertCollision.showAndWait();
                    return;
                }

                /** Checks if an appointment starts before an ongoing appointment and ends after the ongoing appointment finishes.*/
                if (a.getStartDate().isBefore(startDateTime) && a.getEndDate().isAfter(endDateTime)) {

                    /** Displays alert message if appointment collides.*/
                    Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
                    confirmAddition.setTitle("Appointment");
                    confirmAddition.setContentText("Appointment collides!");
                    confirmAddition.showAndWait();
                    return;
                }

                /** SPECIFIC CODE FOR WHEN UPDATING AN APPOINTMENT FOR A CUSTOMER.**/

                /** Checks if the appointment to be updated has a different ID than previous appointments created for the same customer.*/
                if(a.getId() != appointmentId){

                    /** Checks if the appointment to be updated happens at the same time as another appointment for the same customer.*/
                    if( a.getStartDate().isEqual(startDateTime) && a.getEndDate().isEqual(endDateTime)) {

                        /** Displays alert message if appointment collides.*/
                        Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
                        confirmAddition.setTitle("Appointment");
                        confirmAddition.setContentText("Appointment collides!");
                        confirmAddition.showAndWait();
                        return;
                    }
                }
            }


            /** Checks for empty text fields and no item selected from the combo boxes.*/
            if (!title.isEmpty() && !description.isEmpty() && !location.isEmpty() && !contactCmb.getSelectionModel().isEmpty() &&
                    !userIDCmb.getSelectionModel().isEmpty() && !startTimeCmb.getSelectionModel().isEmpty() && !typeCmb.getSelectionModel().isEmpty()) {

                /** Updates the appointment in the database by calling the appointmentCRUD method and passing the data.*/
                int rowsAffected = AppointmentCRUD.update(appointmentId, title, description, location, contactId, customerId, userId, startDateTime, endDateTime, type);

                /** Checks if the rows affected is greater than 0.*/
                if (rowsAffected > 0) {

                    /** Creates an appointment  object.*/
                    Appointment a = new Appointment(appointmentId, title, description, location, type, startDateTime, endDateTime, customerId, userId, contactId);

                    /** Updates the appointment.*/
                    ListManager.allAppointments.set(index, a);

                    /** Displays message if appointment is updated successfully.*/
                    Alert confirmUpdate = new Alert(Alert.AlertType.INFORMATION);
                    confirmUpdate.setTitle("Appointment");
                    confirmUpdate.setContentText("Appointment updated successfully!");
                    confirmUpdate.showAndWait();
                }
            } else {

                /** Displays message if appointment is not added.*/
                Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
                confirmAddition.setTitle("Appointment");
                confirmAddition.setContentText("Please enter or select data in the missing fields.");
                confirmAddition.showAndWait();
                return;
            }

        } catch (Exception e){

            /** Displays message if appointment is not added.*/
            Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
            confirmAddition.setTitle("Appointment");
            confirmAddition.setContentText("Please enter values for the fields.");
            confirmAddition.showAndWait();
            return;
        }

        /** Loads the Appointments Form.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/AppointmentsForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
        stage.setTitle("Appointments Form");
        stage.setScene(new Scene(root, 1360, 467));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the EventHandler for the Cancel button.
     * When the Cancel button is clicked the user is sent to the Appointments form and does not update the appointment selected.
     * @param actionEvent Not used.
     * @throws IOException Used to handle code failures if needed.
     */
    public void onActionCancel(ActionEvent actionEvent) throws IOException {

        /** Displays alert message if appointment collides.*/
        Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
        confirmAddition.setTitle("Appointment");
        confirmAddition.setContentText("Appointment was not updated.");
        confirmAddition.showAndWait();


        /** Loads the Appointments Form.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/AppointmentsForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
        stage.setTitle("Appointments Form");
        stage.setScene(new Scene(root, 1360, 467));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the Event Handler for the Select Start time combo box.
     * When the user selects a time from the start time combo box, it automatically selects its end time.
     * @param actionEvent Not used.
     */
    public void onActionSelectStartTime(ActionEvent actionEvent) {

        /** Stores the hour selected from the start time combo box.*/
        int hour = startTimeCmb.getValue().getHour();

        /** Sets the time for the end time combo box by using the generateTimes method.*/
        endTimeCmb.setItems(TimeManager.generateTimes(hour+1, 24));
        endTimeCmb.getItems().add(LocalTime.of(0, 0));

        /** Selects the first hour from the end time combo box.*/
        endTimeCmb.getSelectionModel().selectFirst();
    }

    /**
     * Event Handler for the Start Date Picker widget.
     * When the user chooses a Start date, it sets the EndDate DatePicker to the same day automatically.
     * @param actionEvent actionEvent not used.
     */
    public void onActionSelectStartDate(ActionEvent actionEvent) {

        /** Sets the EndDate DatePicker to the same date chosen from the StartDate Picker.*/
        endDatePicker.setValue(startDatePicker.getValue());
    }
}
