package controller;

import expressions.UserLogin;
import helper.CustomerCRUD;
import helper.ListManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointment;
import model.Customer;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

/** This class displays the Customers Form. The user can view, add, update and delete a customer from this screen.*/
public class CustomersForm implements Initializable {

    /** CUSTOMERS TABLEVIEW*/

    /** GUI Control for the customers' table view.*/
    @FXML
    public TableView<Customer> customersTableView;
    /** Table column for the customer ID.*/
    @FXML
    public TableColumn<Customer, Integer> customerIdCol;
    /** Table column for the customer name.*/
    @FXML
    public TableColumn<Customer, String> customerNameCol;
    /** Table column for the customer address.*/
    @FXML
    public TableColumn<Customer, String> customerAddressCol;
    /** Table column for the customer postal code.*/
    @FXML
    public TableColumn<Customer, String> customerPostalCodeCol;
    /** Table column for the customer phone number.*/
    @FXML
    public TableColumn<Customer, String> customerPhoneNumberCol;
    /** Table column for the customer state or province..*/
    @FXML
    public TableColumn<Customer, String> customerStateProvinceCol;
    /** Table column for the customer country.*/
    @FXML
    public TableColumn<Customer, String> customerCountry;

    private int index;

    /**
     * This is the initialize method.
     * This is the first method that is called when the screen associated with this controller gets instantiated.
     * @param url Not used.
     * @param resourceBundle Not used.
     */
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /**CUSTOMERS TABLE VIEW*/

        /** Populates the Customers' table view with the allCustomers list.*/
        customersTableView.setItems(ListManager.allCustomers);

        /** This statement gets the id from the getId method of every customer object created.*/
        customerIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        /** This statement gets the name from the getName method of every customer object created.*/
        customerNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        /** This statement gets the address from the getAddress method of every customer object created.*/
        customerAddressCol.setCellValueFactory(new PropertyValueFactory<>("address"));

        /** This statement gets the postal code from the getPostalCode method of every customer object created.*/
        customerPostalCodeCol.setCellValueFactory(new PropertyValueFactory<>("postalCode"));

        /** This statement gets the phone number from the getPhoneNumber method of every customer object created.*/
        customerPhoneNumberCol.setCellValueFactory(new PropertyValueFactory<>("phone"));

        /** This statement gets the state or province from the getFirstLevelDivision method of every customer object created.*/
        customerStateProvinceCol.setCellValueFactory(new PropertyValueFactory<>("firstLevelDivision"));

        /** This statement gets the country from the getCountry method of every customer object created.*/
        customerCountry.setCellValueFactory(new PropertyValueFactory<>("country"));
    }

    /**
     * This is the EventHandler for the Main Form button.
     * When the Main Form button is clicked the user is sent to the Main form.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionMainForm(ActionEvent actionEvent) throws IOException {

        /** Displays the Main form screen.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setTitle("Main Form");
        stage.setScene(new Scene(root, 400, 350));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the EventHandler for the Appointments Form button.
     * When the Appointments Form button is clicked the user is sent to the Appointments form.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionAppointmentsForm(ActionEvent actionEvent) throws IOException {

        /** Displays the Appointments Form screen.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/AppointmentsForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setTitle("Appointments Form");
        stage.setScene(new Scene(root, 1360, 467));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the EventHandler for the Add Customer button.
     * When the Add Customer button is clicked the user is sent to the Add Customer form.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionAddCustomer(ActionEvent actionEvent) throws IOException {

        /** Displays the Add Customer form screen.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/AddCustomer.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setTitle("Appointments Form");
        stage.setScene(new Scene(root, 600, 430));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the EventHandler for the Update Customer button.
     * When the Update Customer button is clicked the user is sent to the Update Customer form.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionUpdateCustomer(ActionEvent actionEvent) throws IOException {

        /**Creates a new loader object.*/
        FXMLLoader loader = new FXMLLoader();

        /** Loads the Update Customer form screen.*/
        loader.setLocation(getClass().getResource("/view/UpdateCustomer.fxml"));
        loader.load();

        /** Creates a reference variable for the UpdateCustomer controller.*/
        UpdateCustomer UCController = loader.getController();

        /**Creates a reference variable for the Customers class and sets it equal the selected item in the customersTableView.*/
        Customer selectedCustomer = customersTableView.getSelectionModel().getSelectedItem();

        /**Creates a variable and sets it equal to the selected index in the customers' table view.*/
        int selectedIndex = customersTableView.getSelectionModel().getSelectedIndex();

        /** Checks if the user selected a customer or not.*/
        if (selectedCustomer != null) {

            /**UCController is used to access the sendData method*/
            UCController.sendData(selectedIndex, selectedCustomer);

            /** Displays the Update Customer form.*/
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene, 600, 400));
            stage.show();

        } else {

            /** Displays an error message if the user does not select a customer to update.*/
            Alert selectItemError = new Alert(Alert.AlertType.ERROR);
            selectItemError.setTitle("Error Dialog");
            selectItemError.setContentText("Please select a customer to update.");
            selectItemError.showAndWait();
        }
    }

    /**
     * This is the Event Handler for the Delete Customer button.
     * It deletes a customer from the application and database when used.
     * @param actionEvent Not used.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public void onActionDeleteCustomer(ActionEvent actionEvent) throws SQLException {

        /** Gets customer from tableView.*/
        Customer selectedCustomer = customersTableView.getSelectionModel().getSelectedItem();

        /** Checks if a customer is selected or not.*/
        if (selectedCustomer != null) {

            /** Dialogue box message that confirms whether the customer is to be deleted or not.*/
            Alert confirmDeletion = new Alert(Alert.AlertType.CONFIRMATION);
            confirmDeletion.setTitle("Customer Deletion");
            confirmDeletion.setContentText("Are you sure you want to delete this customer?" + "\n" +
                                           "- Deleting a customer will also delete all appointments" + "\n" +
                                           "booked for this customer.");
            Optional<ButtonType> result = confirmDeletion.showAndWait();

            /** Checks if the user clicks the OK button on the dialogue box.*/
            if (result.isPresent() && result.get() == ButtonType.OK) {

                    try{
                        /** Calls method that deletes selected customer from the database.*/
                        int rowsAffected = CustomerCRUD.delete(selectedCustomer.getId());

                        /** Checks if there are any rows affected.*/
                        if (rowsAffected > 0) {
                            //int count = 0;

                            /** Creates a list of appointments to be deleted.*/
                            ObservableList<Appointment> deleteAppointments = FXCollections.observableArrayList();

                            /** For loop that searches for appointment in the list of appointments.*/
                            for(Appointment a : ListManager.allAppointments) {

                                /** Checks if there are any appointments with the same customer ID as the selected customer.*/
                                 if(a.getCustomerId() == selectedCustomer.getId()) {

                                     /** Adds appointments to the deleteAppointments list.*/
                                     deleteAppointments.add(a);
                                 }
                            }

                            /** Searches for appointments in the list of deleted appointments.*/
                            for(Appointment a : deleteAppointments){

                                /** Removes all the appointments to be deleted from the allAppointments list.*/
                                ListManager.allAppointments.remove(a);
                            }

                            /** Removes the selected customer from the allCustomers list.*/
                            ListManager.allCustomers.remove(selectedCustomer);

                            /** Displays dialog message when a customer is removed.*/
                            Alert confirmedDeletion = new Alert(Alert.AlertType.INFORMATION);
                            confirmedDeletion.setTitle("Customer Deletion");
                            confirmedDeletion.setContentText("Customer deleted successfully.");
                            confirmedDeletion.show();
                        }

                    }catch (Exception e){
                       // e.getMessage();
                }

            } else {

                /** Display error message if user clicks cancel in the confirmation dialogue box.*/
                Alert confirmedDeletion = new Alert(Alert.AlertType.INFORMATION);
                confirmedDeletion.setTitle("Customer");
                confirmedDeletion.setContentText("Customer was not deleted.");
                confirmedDeletion.show();
            }
        }
        else{

            /** Display error message if user clicks cancel in the confirmation dialogue box.*/
            Alert confirmedDeletion = new Alert(Alert.AlertType.ERROR);
            confirmedDeletion.setTitle("Customer");
            confirmedDeletion.setContentText("Please select a customer to delete.");
            confirmedDeletion.show();
        }
    }
}
