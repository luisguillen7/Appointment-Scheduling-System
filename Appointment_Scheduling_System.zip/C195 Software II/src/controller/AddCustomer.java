package controller;

import helper.CustomerCRUD;
import helper.ListManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import model.Country;
import model.Customer;
import model.FirstLevelDivision;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/** This class displays the Add Customer Form. The user can add an appointment from this screen.*/
public class AddCustomer implements Initializable {

    /** GUI Control for Customer ID text field.*/
    @FXML
    public TextField customerIdTxtField;
    /** GUI Control for Name text field.*/
    @FXML
    public TextField nameTxtField;
    /** GUI Control for Address text field.*/
    @FXML
    public TextField addressTxtField;
    /** GUI Control for Postal Code text field.*/
    @FXML
    public TextField postalCodeTxtField;
    /** GUI Control for Phone text field.*/
    @FXML
    public TextField phoneTxtField;
    /** GUI Control for Country combo box.*/
    @FXML
    public ComboBox<Country> countryComboBox;
    /** GUI Control for First Level Division combo box.*/
    @FXML
    public ComboBox<FirstLevelDivision> firstLevelDivisionComboBox;

    /** List that stores the filtered divisions.*/
    ObservableList<FirstLevelDivision> filteredDivisions = FXCollections.observableArrayList();

    /**
     * This is the initialize method.
     * This is the first method that is called when the screen associated with this controller gets instantiated.
     * @param url Not used.
     * @param resourceBundle Not used.
     */
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /** Populates Country ComboBox */
        countryComboBox.setItems(ListManager.allCountries);

        /** Displays an item on the Country Box */
        countryComboBox.getSelectionModel().selectFirst();

        /** Variable that stores the country ID from the combo box */
        int countryID = countryComboBox.getValue().getCountryId();

        /** Loop that filters the list*/
        for(FirstLevelDivision f : ListManager.allDivisions){

            /** Checks if the first level division's country ID matches the country ID from the country selected from the combo box.*/
            if(f.getCountryId() == countryID){

                /** If a match exists all the first level divisions with a matching country ID is added to the filtered divisions list.*/
                filteredDivisions.add(f);
            }
        }

        /** Populates First Level Division ComboBox */
        firstLevelDivisionComboBox.setItems(filteredDivisions);

        /** Selects the first item of the first level division combo box.*/
        firstLevelDivisionComboBox.getSelectionModel().selectFirst();
    }


    /**
     * This is the EventHandler for the Save button.
     * When the Save button is clicked the user is sent to the Customers form and adds a new customer to the table.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionSave(ActionEvent actionEvent) throws IOException {
        try{

            /** Getting input from the TextFields.*/
            String name = nameTxtField.getText();
            String address = addressTxtField.getText();
            String postalCode = postalCodeTxtField.getText();
            String phone = phoneTxtField.getText();

            /** These string variables are used to display info on the GUI.*/
            String firstLevelDivision = String.valueOf(firstLevelDivisionComboBox.getValue());
            String country = String.valueOf(countryComboBox.getValue());

            /** These int variables are used to pass info to the database.*/
            int firstLevelDivisionId = firstLevelDivisionComboBox.getValue().getDivisionId();
            int countryId = countryComboBox.getValue().getCountryId();

            /** Hardcoded names for testing purposes.*/
            String createdBy = "Luis";

            /** Checks if the text fields are not empty.*/
            if(!name.isEmpty() && !address.isEmpty() && !postalCode.isEmpty() && !phone.isEmpty()){

                /** Calls the insert method and is passed the values from the textFields and comboBoxes. It's stored into rowsAffected.*/
                int rowsAffected = CustomerCRUD.insert(name, address, postalCode, phone, createdBy, firstLevelDivisionId);

                /** Checks if rowsAffected is greater than 0.*/
                if(rowsAffected > 0){

                    /** Adds new customer to the list and consequentially to the GUI.*/
                    int customerId = CustomerCRUD.getMaxId();
                    Customer c = new Customer(customerId, name, address, postalCode, phone, firstLevelDivision, country, firstLevelDivisionId, countryId);
                    ListManager.allCustomers.add(c);

                    /** Displays message if customer is successfully deleted.*/
                    Alert confirmAddition = new Alert(Alert.AlertType.INFORMATION);
                    confirmAddition.setTitle("Customer");
                    confirmAddition.setContentText("Customer added successfully!");
                    confirmAddition.showAndWait();

                    /** Takes the user back to the Customers Form.*/
                    Parent root = FXMLLoader.load(getClass().getResource("/view/CustomersForm.fxml"));
                    Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
                    stage.setTitle("Customers Form");
                    stage.setScene(new Scene(root, 1089, 467));
                    stage.setResizable(false); /** Keeps user from resizing the window **/
                    stage.show();
                }
            }
            /** Checks if the name text field is empty.*/
            else if(name.isEmpty()){
                Alert checkField = new Alert(Alert.AlertType.INFORMATION);
                checkField.setTitle("Customer");
                checkField.setContentText("Please enter a valid name.");
                checkField.showAndWait();
            }
            /** Checks if the address field is empty.*/
            else if(address.isEmpty()){
                Alert checkField = new Alert(Alert.AlertType.INFORMATION);
                checkField.setTitle("Customer");
                checkField.setContentText("Please enter a valid address.");
                checkField.showAndWait();
            }
            /** Checks if the postal code field is empty.*/
            else if(postalCode.isEmpty()){
                Alert checkField = new Alert(Alert.AlertType.INFORMATION);
                checkField.setTitle("Customer");
                checkField.setContentText("Please enter a valid postal code.");
                checkField.showAndWait();
            }
            /** Checks if the phone field is empty.*/
            else if(phone.isEmpty()){
                Alert checkField = new Alert(Alert.AlertType.INFORMATION);
                checkField.setTitle("Customer");
                checkField.setContentText("Please enter a valid phone.");
                checkField.showAndWait();
            }
        }
         catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * This is the EventHandler for the CANCEL button.
     * When the Cancel button is clicked the user is sent to the Customers form and does not add a new customer to the table.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionCancel(ActionEvent actionEvent) throws IOException {

        /** Displays message if the CANCEL button is clicked.*/
        Alert confirmCancellation = new Alert(Alert.AlertType.INFORMATION);
        confirmCancellation.setTitle("Customer");
        confirmCancellation.setContentText("Customer was not added.");
        confirmCancellation.showAndWait();

        /** Takes user back to the Customers Form.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/CustomersForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
        stage.setTitle("Customers Form");
        stage.setScene(new Scene(root, 1089, 467));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();
    }

    /**
     * This is the Event Handler for the country combo box.
     * It allows the country combo box to filter the first level division combo box with its correspondent divisions.
     * @param actionEvent Not used.
     */
    public void onActionSelectCountry(ActionEvent actionEvent) {

        /** Clears the list*/
        filteredDivisions.clear();

        /** Variable that stores an item retrieved from the combo box */
        int countryID = countryComboBox.getValue().getCountryId();

        /** Variable that stores an item retrieved from the combo box */
        for(FirstLevelDivision f : ListManager.allDivisions){

            /** Checks if the first level division's country ID matches the country ID from the country selected from the country combo box.*/
            if(f.getCountryId() == countryID){

                /** Adds all the first level divisions with a matching country ID to the filtered divisions list.*/
                filteredDivisions.add(f);
            }
        }

        /** Sets the division combo box to display the filtered divisions list.*/
        firstLevelDivisionComboBox.setItems(filteredDivisions);

        /** Displays the first item of the list.*/
        firstLevelDivisionComboBox.getSelectionModel().selectFirst();
    }
}
