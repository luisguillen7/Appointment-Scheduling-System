package controller;

import helper.ListManager;
import helper.ReportsCRUD;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointment;
import model.Contact;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ResourceBundle;

/** This class displays the Reports Form. The user can view the number of appointments booked by contact, by type, by month and by user session.*/
public class ReportsForm implements Initializable {

    /** GUI Control for the appointments' table view.*/
    @FXML
    public TableView<Appointment> appointmentsTableView;

    /** Table column for the appointment ID.*/
    @FXML
    public TableColumn<Appointment, Integer> appointmentId;

    /** Table column for the appointment title.*/
    @FXML
    public TableColumn<Appointment, String> title;

    /** Table column for the appointment type.*/
    @FXML
    public TableColumn<Appointment, String> type;

    /** Table column for the appointment description.*/
    @FXML
    public TableColumn<Appointment, String> description;

    /** Table column for the appointment start date and time.*/
    @FXML
    public TableColumn<Appointment, LocalDateTime> startDateTime;

    /** Table column for the appointment end date and time.*/
    @FXML
    public TableColumn<Appointment, LocalDateTime> endDateTime;

    /** Table column for the customer ID.*/
    @FXML
    public TableColumn<Appointment, Integer> customerId;

    /** Table column for the contact ID.*/
    @FXML
    public TableColumn<Appointment, Integer> contactId;

    /** GUI Control for the contact combo box.*/
    @FXML
    public ComboBox<Contact> contactCmb;

    /** GUI Control for the appointment month text field.*/
    @FXML
    public TextField appointmentsByMonthAndType;

    /** GUI Control for the type combo box.*/
    @FXML
    public ComboBox<String> typeCmb;

    /** GUI Control for the month combo box. */
    @FXML
    public ComboBox<Month> monthCmb;

    /** GUI Control for the user combo box.*/
    @FXML
    public ComboBox<User> userCmb;

    /** GUI Control for the user text field.*/
    @FXML
    public TextField appointmentsByUserTxt;

    /** GUI Control for the total appointments field.*/
    @FXML
    public TextField numberOfAppointmentsByContact;

    /** List that stores months using enum values.*/
    ObservableList<Month> allMonths = FXCollections.observableArrayList();

    /**
     * This is the initialize method.
     * This is the first method that is called when the screen associated with this controller gets instantiated.
     * @param url Not used.
     * @param resourceBundle Not used.
     */
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /** APPOINTMENTS TABLE VIEW.*/

        /** Populates the appointments' table view with the allAppointments list.*/
        appointmentsTableView.setItems(ListManager.allAppointments);

        /** This statement gets the id from the getId method of every appointment object created.*/
        appointmentId.setCellValueFactory(new PropertyValueFactory<>("id"));

        /** This statement gets the title from the getTitle method of every appointment object created.*/
        title.setCellValueFactory(new PropertyValueFactory<>("title"));

        /** This statement gets the description from the getDescription method of every appointment object created.*/
        description.setCellValueFactory(new PropertyValueFactory<>("description"));

        /** This statement gets the type from the getType method of every appointment object created.*/
        type.setCellValueFactory(new PropertyValueFactory<>("type"));

        /** This statement gets the startDate from the getStartDate method of every appointment object created.*/
        startDateTime.setCellValueFactory(new PropertyValueFactory<>("startDate"));

        /** This statement gets the endDate from the getEndDate method of every appointment object created.*/
        endDateTime.setCellValueFactory(new PropertyValueFactory<>("endDate"));

        /** This statement gets the customer id from the getId method of every appointment object created.*/
        customerId.setCellValueFactory(new PropertyValueFactory<>("customerId"));

        /** This statement gets the contact id from the getId method of every appointment object created.*/
        contactId.setCellValueFactory(new PropertyValueFactory<>("contactId"));

        /** Populates the Contact combo box with the allContacts list.*/
        contactCmb.setItems(ListManager.allContacts);

        /** Populates the User combo box with the allUsers list.*/
        userCmb.setItems(ListManager.allUsers);

        /** Sets the Users' prompt text.*/
        userCmb.setPromptText("Select User");

        /** Populates the Type combo box with the allTypes list.*/
        typeCmb.setItems(ListManager.allTypes);

        /** Sets the Types' prompt text.*/
        typeCmb.setPromptText("Select Type");

        /** Populates the allMonths list with the months.*/
        for(int i = 1; i < 13; i++){
            allMonths.add(LocalDate.of(2022, i, 1).getMonth());
        }

        /** Populates the month combo box with the allMonths list.*/
        monthCmb.setItems(allMonths);

        /** Sets the Month's prompt text.*/
        monthCmb.setPromptText("Select Month");
    }

    /**
     * This is the Event Handler for the Main form button.
     * When the Main form button is clicked, the user is sent to the Main form screen.
     * @param actionEvent Not used.
     * @throws IOException To handle code failures if needed.
     */
    public void onActionMainForm(ActionEvent actionEvent) throws IOException {

        /** Loads the Main form screen.*/
        Parent root = FXMLLoader.load(getClass().getResource("/view/MainForm.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();;
        stage.setTitle("Main Form");
        stage.setScene(new Scene(root, 400, 350));
        stage.setResizable(false); /** Keeps user from resizing the window **/
        stage.show();

    }

    /**
     * This is the Event Handler for the Select Contact combo box.
     * When the user selects a contact, the table view displays the appointments booked by contact.
     * @param actionEvent Not used.
     * @throws SQLException To handle code failures if needed.
     */
    public void onActionSelectContact(ActionEvent actionEvent) throws SQLException {

        /** Variable that stores the selected contact from the combo box.*/
        int selectedContact = contactCmb.getSelectionModel().getSelectedIndex();

        /** Clears the appointmentsByContact list.*/
        ListManager.appointmentsByContacts.clear();

        /** Calls the selectAppointmentsByContact and passes the selected contact from the combo box.*/
        ReportsCRUD.selectAppointmentsByContact(selectedContact + 1);

        /** Populates the appointments' table view with the appointmentsByContacts list.*/
        appointmentsTableView.setItems(ListManager.appointmentsByContacts);

        numberOfAppointmentsByContact.setText(String.valueOf(ListManager.appointmentsByContacts.size()));
    }


    /**
     * This is the Event Handler for the Select Month combo box.
     * WHen the user selects a month, the text field displays the number of appointments by month.
     * @param actionEvent Not used.
     * @throws SQLException To handle code failures if needed.
     */
    public void onActionSelectMonth(ActionEvent actionEvent) throws SQLException {

            /** Creates variable that stores the month from selected from the month combo box.*/
            int month = monthCmb.getValue().getValue();

            /** Creates variable that stores the type selected from the type combo box.*/
            String type = typeCmb.getValue();

            /** Creates list that stores the number of appointments by month and type.*/
            ObservableList<Appointment> numberOfAppointments = ReportsCRUD.selectAppointmentsByMonthAndType(month, type);

            /** */
            if(numberOfAppointments != null){

                /** Populates the appointmentsByMonthAndType text field with the numberOfAppointmentsByMonthAndType list.*/
                appointmentsByMonthAndType.setText(String.valueOf(numberOfAppointments.size()));
            }
            else{

                /** If no appointments of either type are found in a month, appointmentsByMonthAndType are set to 0.*/
                appointmentsByMonthAndType.setText("0");
            }

    }

    /**
     * This is the Event Handler for the Select User combo box.
     * When the user selects a user, the text field displays the number of appointments booked by user session.
     * @param actionEvent Not used.
     * @throws SQLException To handle code failures if needed.
     */
    public void onActionSelectUser(ActionEvent actionEvent) throws SQLException {

       /** Retrieves the ID of the selected user from the users' combo box.*/
       int selectedUser = userCmb.getValue().getId();

       /** List that holds the number of appointments booked by the selected user.*/
       ObservableList<Appointment> numberOfAppointments = ReportsCRUD.numberOfAppointmentsByUser(selectedUser);

       /** Checks if the numberOfAppointments holds data.*/
       if(numberOfAppointments != null){

           /** Displays the size of the numberOfAppointments on the text field.*/
           appointmentsByUserTxt.setText(String.valueOf(numberOfAppointments.size()));

       } else{

           /** Displays 0 if no appointments are found.*/
           appointmentsByUserTxt.setText("0");
       }
    }
}
