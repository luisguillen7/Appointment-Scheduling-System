package main;

import helper.*;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/** This is the main class. This class opens and closes the connection with the database and runs the application.*/
public class Main extends Application {

    /**
     * This is the start method.
     * This method loads the log-in form.
     * @param stage Sets the stage for the GUI screen.
     * @throws Exception To handle code failures if needed.
     */
    public void start(Stage stage) throws Exception {

        try{

            /** Gets the resource bundle depending on the system's default locale.*/
            ResourceBundle rb = ResourceBundle.getBundle("resourcebundle/Nat", Locale.getDefault());

            /** Loads the log-in form.*/
            Parent root = FXMLLoader.load(getClass().getResource("/view/LoginForm.fxml"));
            stage.setTitle(rb.getString("Login") + " " + rb.getString("Form"));
            stage.setScene(new Scene(root, 498, 320));
            stage.setResizable(false); /** Keeps user from resizing the window **/
            stage.show();

        }
        /** Catches exception in case a resource bundle is not found.*/
        catch (MissingResourceException e){
        }
    }

    /**
     * This is the main method.
     * This method executes the application. It also opens and closes the connection with the database.
     * @param args Used to launch the application.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static void main(String[] args) throws SQLException {

        /** Creates connection to the database.*/
        JDBC.openConnection();

        /** Retrieves customers from the database.*/
        CustomerCRUD.select();

        /** Retrieves appointments from the database.*/
        AppointmentCRUD.select();

        /** Retrieves countries from the database.*/
        CountryCRUD.select();

        /** Retrieves first level divisions from the database.*/
        DivisionCRUD.select();

        /** Retrieves users from the database.*/
        UserCRUD.select();

        /** Retrieves contacts from the database.*/
        ContactCRUD.select();

        /** Starts the application.*/
        launch(args);

        /** Closes the database connection.*/
        JDBC.closeConnection();
    }
}

