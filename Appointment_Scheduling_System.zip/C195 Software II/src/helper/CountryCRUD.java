package helper;

import model.Country;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/** This class stores the method that displays all the countries from the database.*/
public class CountryCRUD {

    /**
     * This is the select method.
     * This method gets the data from the countries table and displays it.
     * @throws SQLException To handle SQL code failures if needed.
     */
        public static void select() throws SQLException {

        /** SQL Query.*/
        String sql = "SELECT COUNTRY_ID, COUNTRY FROM COUNTRIES";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){

            /** Gets the data from the countries' table columns.*/
            int countryId = rs.getInt("country_id");
            String country = rs.getString("country");

            /** Creates a new country object.*/
            Country c = new Country(countryId, country);

            /** Adds the country object to the allCountries list.*/
            ListManager.allCountries.add(c);
        }
    }
}
