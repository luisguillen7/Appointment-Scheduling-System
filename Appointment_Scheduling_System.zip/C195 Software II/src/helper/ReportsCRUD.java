package helper;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointment;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

/** This class stores methods that display reports.*/
public class ReportsCRUD {

    /**
     * This is the selectAppointmentsByContact method.
     * This method is used to display appointments by their contact.
     * @param contact The contact.
     * @return Returns appointments booked with a certain contact.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static ObservableList<Appointment> selectAppointmentsByContact(int contact) throws SQLException {

        /** SQL Query.*/
        String sql = "SELECT * FROM client_schedule.appointments WHERE Contact_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, contact);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){

            /** Gets data from the appointments' table columns.*/
            int appointmentId = rs.getInt("APPOINTMENT_ID");
            String title = rs.getString("TITLE");
            String description = rs.getString("DESCRIPTION");
            String type = rs.getString("TYPE");
            LocalDateTime startDate = rs.getTimestamp("START").toLocalDateTime();
            LocalDateTime endDate = rs.getTimestamp("END").toLocalDateTime();
            int customerId = rs.getInt("CUSTOMER_ID");
            int contactId = rs.getInt("CONTACT_ID");

            /** Creates a customer item for each item found in the database.*/
            Appointment a = new Appointment(appointmentId, title, description, null, type , startDate, endDate, customerId, 0, contactId);

            /** Add the newly created customer to the Customers list*/
            ListManager.appointmentsByContacts.add(a);
        }
        /** Checks if there are no appointments found in the list*/
        if(ListManager.appointmentsByContacts.isEmpty()){

            /** Returns nothing if the list is empty.*/
            return null;
        }

        /** Otherwise, it returns the list with the all the appointments in that month*/
        return ListManager.appointmentsByContacts;
    }

    /**
     * This is the appointment alert.
     * This method alerts the user when an appointment is within 15 minutes.
     * @return Returns an appointment within 15 minutes.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static int appointmentAlert() throws SQLException {

        /** SQL Query.*/
        String sql = "SELECT * FROM client_schedule.appointments WHERE date_format(Start, '%Y-%m-%d') >= curDate() and date_format(Start, '%Y-%m-%d') <= DATE_ADD(curDate(), INTERVAL 1 DAY)  and Start >= curtime() limit 1";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        if(rs.next()) {

            /** Gets data from the appointments' table columns.*/
            LocalDateTime s = rs.getTimestamp("Start").toLocalDateTime();
            int appointmentId = rs.getInt("APPOINTMENT_ID");
            LocalDateTime startDateTime = rs.getTimestamp("START").toLocalDateTime();
            int userId = rs.getInt("USER_ID");

            /** Creates an appointment object.*/
            Appointment a  = new Appointment(appointmentId, null, null, null, null, startDateTime, null, 0,  userId, 0);

            /** Adds the appointment to the upcomingAppointment list.*/
            ListManager.upcomingAppointment.add(a);

            /** Checks if the local date from the appointment is equal to the system's date.*/
            if(s.toLocalDate().equals(LocalDate.now())) {

                /** Creates a variable that stores the difference in minutes between the system's local time and the appointment's start time.*/
                long diff = ChronoUnit.MINUTES.between(LocalTime.now().truncatedTo(ChronoUnit.MINUTES), s);

                /** Returns the difference in minutes.*/
                return (int)diff;
            }
            else
                return -1;
        }
        return -1;
    }

    /**
     * This is the numberOfAppointmentsByUserSession method.
     * This method displays all the appointments booked by user.
     * @param user_Id The ID of the user.
     * @return Returns all the appointments booked by the selected user.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static ObservableList<Appointment> numberOfAppointmentsByUser(int user_Id) throws SQLException {

        /** List that stores all the appointments by the selected user.*/
        ObservableList<Appointment> filteredAppointments = FXCollections.observableArrayList();

        /** SQL Query*/
        String sql = "SELECT * FROM APPOINTMENTS \n" +
                     "WHERE USER_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, user_Id);
        ResultSet rs = ps.executeQuery();
        while (rs.next()){

            /** Gets data from the appointments' table columns.*/
            int appointmentId = rs.getInt("APPOINTMENT_ID");
            String title = rs.getString("TITLE");
            String description = rs.getString("DESCRIPTION");
            String type = rs.getString("TYPE");
            LocalDateTime startDate = rs.getTimestamp("START").toLocalDateTime();
            LocalDateTime endDate = rs.getTimestamp("END").toLocalDateTime();
            int customerId = rs.getInt("CUSTOMER_ID");
            int userId = rs.getInt("USER_ID");

            /** Creates new appointment object.*/
            Appointment a = new Appointment(appointmentId, title, description, null, type, startDate, endDate, customerId, userId, 0);

            /** Adds the appointment object to the filteredAppointments list.*/
            filteredAppointments.add(a);
        }

        /** Checks if the list ie empty.*/
        if(filteredAppointments.isEmpty()){

            /** Returns null if the list is empty.*/
            return null;
        }

        /** Return the populated list.*/
        return filteredAppointments;
    }


    /**
     * Method that selects appointments based on an SQL query that retrieves rows based on a month and type.
     * @param monthNum Month
     * @param appointmentType Type of appointment.
     * @return Returns a list with all the appointments within a month and of either type.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static ObservableList<Appointment> selectAppointmentsByMonthAndType(int monthNum, String appointmentType) throws SQLException {

        /** List that stores the number of appointments by mont and type.*/
         ObservableList<Appointment> appointmentsByMonthAndType = FXCollections.observableArrayList();


        /** SQL Query.*/
        String sql = "SELECT APPOINTMENT_ID, TITLE, DESCRIPTION, LOCATION, TYPE, CONTACT_ID, CUSTOMER_ID, USER_ID, START, END\n" +
                "FROM APPOINTMENTS\n" +
                "WHERE MONTH(START) = ?\n" +
                "AND TYPE = ?";

        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, monthNum);
        ps.setString(2, appointmentType);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){

            /** Gets the data from the appointments' table columns.*/
            int appointmentId = rs.getInt("APPOINTMENT_ID");
            String title = rs.getString("TITLE");
            String description = rs.getString("DESCRIPTION");
            String location = rs.getString("LOCATION");
            String type = rs.getString("TYPE");
            LocalDateTime startDate = rs.getTimestamp("START").toLocalDateTime();
            LocalDateTime endDate = rs.getTimestamp("END").toLocalDateTime();
            int customerId = rs.getInt("CUSTOMER_ID");
            int userId = rs.getInt("USER_ID");
            int contactId = rs.getInt("CONTACT_ID");

            /** Creates a customer item for each item found in the database.*/
            Appointment a = new Appointment(appointmentId, title, description, location, type , startDate, endDate, customerId, userId, contactId);

            /** Add the newly created customer to the Customers list*/
            appointmentsByMonthAndType.add(a);
        }
        /** Checks if there are no appointments found in the list*/
        if(appointmentsByMonthAndType.isEmpty()){

            /** Returns nothing if the list is empty.*/
            return null;
        }

        /** Otherwise, it returns the list with the all the appointments in that month*/
        return appointmentsByMonthAndType;
    }

}
