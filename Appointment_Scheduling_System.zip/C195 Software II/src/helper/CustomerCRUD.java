package helper;

import model.Customer;

import java.sql.*;

/** This class stores all the methods that displays, adds, updates and deletes customers from the database.*/
public abstract class CustomerCRUD {

    /**
     * This is the getMaxId method.
     * This method gets the id from the last customer in the database.
     * @return Returns the last customer from the database.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static int getMaxId() throws SQLException {

        /** SQL Query.*/
        String sql = "SELECT max(Customer_ID) AS Max_Cust_ID FROM customers";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql); // Create Prepared Statement
        ResultSet rs = ps.executeQuery();
        if(rs.next()) {

            /** Gets the customer ID.*/
            return rs.getInt(1);
        }

        /** Returns 0 if no ID is found.*/
        return 0;
    }


    /**
     * This is the insert method.
     * This method is used to insert customer into the database.
     * @param name The name of the customer.
     * @param address The address of the customer.
     * @param postalCode The postal code of the customer.
     * @param phone The phone of the customer.
     * @param createdBy  The user that inserted the customer.
     * @param divisionId The division ID of the state or province where the customer resides.
     * @return Returns the rows affected by the insertion.
     * @throws SQLException Throws any error that is found while interacting with the database.
     */
    public static int insert(String name, String address, String postalCode, String phone, String createdBy, int divisionId ) throws SQLException {

        /** SQL Query.*/
        String sql = "INSERT INTO CUSTOMERS (CUSTOMER_NAME, ADDRESS, POSTAL_CODE, PHONE, CREATE_DATE, CREATED_BY, LAST_UPDATE, LAST_UPDATED_BY, DIVISION_ID) VALUES(?, ?, ?, ?, NOW(), ?, NOW(), 'N/A', ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1, name);
        ps.setString(2, address);
        ps.setString(3, postalCode);
        ps.setString(4, phone);
        ps.setString(5, createdBy);
        ps.setInt(6, divisionId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * This is the update method.
     * This method is used to update a customer from the database.
     * @param customerId The customer's ID.
     * @param name The customer's name.
     * @param address The customer's address.
     * @param postalCode The customer's postal code.
     * @param phone The customer's phone.
     * @param createdBy User that created the customer.
     * @param division The customer's first level division.
     * @return Returns the updated customer.
     * @throws SQLException To handle SQL Code failures if needed.
     */
    public static int update(int customerId, String name, String address, String postalCode, String phone, String createdBy, int division) throws SQLException {

        /** SQL Query.*/
        String sql = "UPDATE CUSTOMERS SET CUSTOMER_NAME = ?, ADDRESS = ?, POSTAL_CODE = ?, PHONE = ?, CREATED_BY = ?, LAST_UPDATE = NOW(), DIVISION_ID = ? WHERE CUSTOMER_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);

        /** Passes data to the customers' columns.*/
        ps.setString(1, name);
        ps.setString(2, address);
        ps.setString(3, postalCode);
        ps.setString(4, phone);
        ps.setString(5, createdBy);
        ps.setInt(6, division);
        ps.setInt(7, customerId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * This is the delete method.
     * This method deletes a customer from the database.
     * @param customerId The customer's ID.
     * @return Returns the deleted customer.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static int delete(int customerId) throws SQLException {

        /** SQL Query.*/
        String sql = "DELETE FROM CUSTOMERS WHERE CUSTOMER_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);

        /** Sets the parameter with the Customer ID passed.*/
        ps.setInt(1, customerId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * This is the select method.
     * This method displays all the customers stored in the database.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static void select() throws SQLException {

        /**SQL Query.*/
        String sql = "SELECT c.Customer_ID, c.Customer_Name, c.Address, c.Postal_Code, c.Phone, f.Division, co.Country, f.Division_ID, co.Country_ID\n" +
                "FROM customers c\n" +
                "INNER JOIN first_level_divisions f \n" +
                "ON c.Division_ID = f.Division_ID\n" +
                "INNER JOIN countries co\n" +
                "ON co.Country_ID = f.Country_ID;";

        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {

            /** Gets data from the customers' table columns.*/
            int id = rs.getInt("Customer_ID");
            String name = rs.getString("Customer_Name");
            String address = rs.getString("Address");
            String postalCode = rs.getString("Postal_Code");
            String phone = rs.getString("Phone");
            String firstLevelDivision = rs.getString("Division");
            String country = rs.getString("Country");
            int divisionId = rs.getInt("Division_ID");
            int countryId = rs.getInt("Country_ID");

            /** Creates a customer item for each item found in the database.*/
            Customer customer = new Customer(id, name, address, postalCode, phone, firstLevelDivision, country, divisionId, countryId);

            /** Add the newly created customer to the Customers list*/
            ListManager.allCustomers.add(customer);
        }
    }
}


