package helper;

import model.FirstLevelDivision;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/** This class stores the method that displays all the first level divisions from the database.*/
public class DivisionCRUD {

    /**
     * This is the select method.
     * This method is used to display all the first level divisions.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static void select() throws SQLException {

        /** SQL Query.*/
        String sql = "SELECT * FROM FIRST_LEVEL_DIVISIONS";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){

            /** Gets data from the first level divisions' table columns.*/
            int divisionId = rs.getInt("DIVISION_ID");
            String division = rs.getString("DIVISION");
            int countryId = rs.getInt("COUNTRY_ID");

            /** Creates a first level division.*/
            FirstLevelDivision f = new FirstLevelDivision(divisionId, division, countryId);

            /** Adds the newly created first level division to the allDivisions list.*/
            ListManager.allDivisions.add(f);
        }
    }

}
