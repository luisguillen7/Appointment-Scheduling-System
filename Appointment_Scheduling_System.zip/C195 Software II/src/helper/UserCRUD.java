package helper;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointment;
import model.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/** This class stores the method that displays all the users from the database.*/
public class UserCRUD {

    /**
     * This is the select method.
     * This method displays all the users from the database.
     * @throws SQLException To handle the SQL code failures if needed.
     */
    public static void select() throws SQLException {

        /** SQL Query.*/
        String sql = "SELECT USER_ID, USER_NAME, PASSWORD FROM USERS";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()) {

            /** Gets data from the users' table columns.*/
            int userId = rs.getInt("USER_ID");
            String userName = rs.getString("USER_NAME");
            String password = rs.getString("PASSWORD");

            /** Creates a user object.*/
            User u = new User(userId, userName, password);

            /** Adds the user to the allUsers list.*/
            ListManager.allUsers.add(u);
        }
    }
}

