package helper;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointment;

import java.sql.*;
import java.time.LocalDateTime;

/** This class stores all the methods that displays, adds, updates and deletes appointments from the database.*/
public class AppointmentCRUD {

    /**
     * This is the select method.
     * The select method displays the appointments stored in the database.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static void select() throws SQLException {

        /** SQL Query.*/
        String sql = "SELECT APPOINTMENT_ID, TITLE, DESCRIPTION, LOCATION, TYPE, START, END, CUSTOMER_ID, USER_ID, CONTACT_ID FROM APPOINTMENTS";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {

            /** Gets data from the Appointments table.*/
            int appointmentId = rs.getInt("APPOINTMENT_ID");
            String title = rs.getString("TITLE");
            String description = rs.getString("DESCRIPTION");
            String location = rs.getString("LOCATION");
            String type = rs.getString("TYPE");
            LocalDateTime startDate = rs.getTimestamp("START").toLocalDateTime();
            LocalDateTime endDate = rs.getTimestamp("END").toLocalDateTime();
            int customerId = rs.getInt("CUSTOMER_ID");
            int userId = rs.getInt("USER_ID");
            int contactId = rs.getInt("CONTACT_ID");

            /** Creates a customer item for each item found in the database.*/
            Appointment a = new Appointment(appointmentId, title, description, location, type , startDate, endDate, customerId, userId, contactId);

            /** Add the newly created customer to the Customers list*/
            ListManager.allAppointments.add(a);
        }
    }

    /**
     * This is the getMaxId method.
     * This method gets the id from the last appointment in the database.
     * @return  Returns an appointment ID.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static int getMaxId() throws SQLException {

        /*** SQL Query.*/
        String sql = "SELECT max(Appointment_Id) AS Max_Appointment_ID FROM APPOINTMENTS";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql); // Create Prepared Statement
        ResultSet rs = ps.executeQuery();
        if(rs.next()) {

            /** Gets the appointment ID.*/
            return rs.getInt(1);
        }

        /** Returns 0 if no ID is found.*/
        return 0;
    }

    /**
     * This is the delete method.
     * This method deletes an appointment from the database.
     * @param appointmentId The appointment ID.
     * @return Returns the appointment to be deleted.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static int delete(int appointmentId) throws SQLException {

        /** SQL Query.*/
        String sql = "DELETE FROM APPOINTMENTS WHERE APPOINTMENT_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, appointmentId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * This is the update method.
     * This method updates an appointment from the database.
     * @param appointmentId The appointment's ID.
     * @param title The appointment's title.
     * @param description The appointment's description.
     * @param location The appointment's location.
     * @param contact The appointment's contact.
     * @param customer The appointment's customer ID.
     * @param user The appointment's user ID.
     * @param startDate The appointment's start date.
     * @param endDate The appointment's end date.
     * @param type The appointment's type.
     * @return Returns the updated appointment.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static int update(int appointmentId, String title, String description, String location, int contact, int customer, int user, LocalDateTime startDate, LocalDateTime endDate, String type) throws SQLException {

        /** SQL Query.*/
        String sql = "UPDATE APPOINTMENTS SET TITLE = ?, DESCRIPTION = ?, LOCATION = ?, TYPE = ?, START = ?, END = ?, CREATED_BY = 'N/A', LAST_UPDATE = NOW(), LAST_UPDATED_BY = 'N/A', CONTACT_ID = ?,  CUSTOMER_ID = ?, USER_ID = ? WHERE APPOINTMENT_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);

        /** Passes data to the appointments' columns.*/
        ps.setString(1, title);
        ps.setString(2, description);
        ps.setString(3, location);
        ps.setString(4, type);
        ps.setString(5, String.valueOf(startDate));
        ps.setString(6, String.valueOf(endDate));
        ps.setInt(7, contact);
        ps.setInt(8, customer);
        ps.setInt(9, user);
        ps.setInt(10, appointmentId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * This is the insert method.
     * This method inserts an appointment to the database.
     * @param title The appointment's title.
     * @param description The appointment's description.
     * @param location The appointment's location.
     * @param type The appointment's type.
     * @param contact The appointment's contact.
     * @param customerId The appointment's customer ID.
     * @param userId The appointment's user ID.
     * @param startDate The appointment's start date.
     * @param endDate The appointment's end date.
     * @return Returns the appointment inserted.
     * @throws SQLException To handle SQL code failures.
     */
    public static int insert(String title, String description, String location, String type, int contact, int customerId, int userId, LocalDateTime startDate, LocalDateTime endDate) throws SQLException {

        /** SQL Query.*/
        String sql = "INSERT INTO APPOINTMENTS (TITLE, DESCRIPTION, LOCATION, TYPE, START, END, CREATE_DATE, CREATED_BY, LAST_UPDATE, LAST_UPDATED_BY, CUSTOMER_ID, USER_ID, CONTACT_ID) VALUES(?, ?, ?, ?, ?, ?, NOW(), 'N/A', NOW(),'N/A', ?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);

       /** Passes data to the appointments' columns.*/
        ps.setString(1, title);
        ps.setString(2,description);
        ps.setString(3, location);
        ps.setString(4, type);
        ps.setTimestamp(5, Timestamp.valueOf(startDate));
        ps.setTimestamp( 6, Timestamp.valueOf(endDate));
        ps.setInt(7,customerId);
        ps.setInt(8, userId);
        ps.setInt(9, contact);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * Method that selects appointments based on an SQL query that retrieves rows based on a month.
     * @param monthNum Month
     * @return Returns a list with all the appointments within a month.
     * @throws SQLException To handle SQL code failures of needed.
     */
    public static ObservableList<Appointment> selectAppointmentsMonthly(int monthNum) throws SQLException {

        /**List that stores only the appointments that belong to a month.*/
        ObservableList<Appointment> filteredAppointments = FXCollections.observableArrayList();

        /** SQL Query.*/
        String sql = "SELECT APPOINTMENT_ID, TITLE, DESCRIPTION, LOCATION, TYPE, CONTACT_ID, CUSTOMER_ID, USER_ID, START, END\n" +
                "FROM APPOINTMENTS\n" +
                "WHERE MONTH(START) = ?";

        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, monthNum);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){

            /** Gets the data from the appointments' table columns.*/
            int appointmentId = rs.getInt("APPOINTMENT_ID");
            String title = rs.getString("TITLE");
            String description = rs.getString("DESCRIPTION");
            String location = rs.getString("LOCATION");
            String type = rs.getString("TYPE");
            LocalDateTime startDate = rs.getTimestamp("START").toLocalDateTime();
            LocalDateTime endDate = rs.getTimestamp("END").toLocalDateTime();
            int customerId = rs.getInt("CUSTOMER_ID");
            int userId = rs.getInt("USER_ID");
            int contactId = rs.getInt("CONTACT_ID");

            /** Creates a customer item for each item found in the database.*/
            Appointment a = new Appointment(appointmentId, title, description, location, type , startDate, endDate, customerId, userId, contactId);

            /** Add the newly created customer to the Customers list*/
            filteredAppointments.add(a);
        }
        /** Checks if there are no appointments found in the list*/
        if(filteredAppointments.isEmpty()){

            /** Returns nothing if the list is empty.*/
            return null;
        }

        /** Otherwise, it returns the list with the all the appointments in that month*/
        return filteredAppointments;
    }

    /**
     * This is the selectAppointmentsWeekly method.
     * This method selects and displays all the appointments for the upcoming week.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static void  selectAppointmentsWeekly() throws SQLException {

        /** SQL Query.*/
        String sql = "SELECT * FROM appointments WHERE start >= curdate() AND start <= DATE_ADD(curdate(), INTERVAL 7 DAY)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {

            /** Gets data from the appointments' table columns.*/
            int appointmentId = rs.getInt("APPOINTMENT_ID");
            String title = rs.getString("TITLE");
            String description = rs.getString("DESCRIPTION");
            String location = rs.getString("LOCATION");
            String type = rs.getString("TYPE");
            LocalDateTime startDate = rs.getTimestamp("START").toLocalDateTime();
            LocalDateTime endDate = rs.getTimestamp("END").toLocalDateTime();
            int customerId = rs.getInt("CUSTOMER_ID");
            int userId = rs.getInt("USER_ID");
            int contactId = rs.getInt("CONTACT_ID");

            /** Creates a customer item for each item found in the database.*/
            Appointment a = new Appointment(appointmentId, title, description, location, type, startDate, endDate, customerId, userId, contactId);

            /** Add the newly created customer to the Customers list*/
            ListManager.weeklyFilteredAppointments.add(a);
        }
    }
}
