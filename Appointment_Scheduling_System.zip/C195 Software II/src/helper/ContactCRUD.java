package helper;

import model.Contact;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/** This class stores the method that displays all the contacts from the database.*/
public class ContactCRUD {

    /**
     * This is the select method.
     * This method gets the data from the contact table and displays it.
     * @throws SQLException To handle SQL code failures if needed.
     */
    public static void select() throws SQLException {

        /** SQL Query*/
        String sql = "SELECT CONTACT_ID, CONTACT_NAME FROM CONTACTS";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()){

            /** Gets the data from the contacts' table columns.*/
            int contactId = rs.getInt("CONTACT_ID");
            String contactName = rs.getString("CONTACT_NAME");

            /** Creates a new contact object.*/
            Contact c = new Contact(contactId, contactName);

            /** Adds the contact object to the allContacts list.*/
            ListManager.allContacts.add(c);
        }
    }
}
