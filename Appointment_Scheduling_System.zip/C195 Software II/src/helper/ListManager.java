package helper;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.*;

/** This class creates all the lists that carry objects related to the database.*/
public class ListManager {

    /** Customer list.*/
    public static ObservableList<Customer> allCustomers = FXCollections.observableArrayList();

    /** Appointment list.*/
    public static  ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();

    /** Countries list.*/
    public static ObservableList<Country> allCountries = FXCollections.observableArrayList();

    /** First level divisions list.*/
    public static ObservableList<FirstLevelDivision> allDivisions = FXCollections.observableArrayList();

    /** Users list.*/
    public static ObservableList<User> allUsers = FXCollections.observableArrayList();

    /** Contacts list.*/
    public static  ObservableList<Contact> allContacts = FXCollections.observableArrayList();

    /** Types list.*/
    public static ObservableList<String> allTypes = FXCollections.observableArrayList("Planning Session", "De-Briefing");

    /** Appointments filtered by week list.*/
    public static ObservableList<Appointment> weeklyFilteredAppointments = FXCollections.observableArrayList();

    /** Appointments filtered by contact list.*/
    public static ObservableList<Appointment> appointmentsByContacts = FXCollections.observableArrayList();

    /** Upcoming appointment in the next 15 minutes list.*/
    public static ObservableList<Appointment> upcomingAppointment = FXCollections.observableArrayList();

}
