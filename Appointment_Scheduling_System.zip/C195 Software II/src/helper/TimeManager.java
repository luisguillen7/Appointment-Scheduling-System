package helper;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.time.LocalTime;

/** This class stores the method that generates the times for the appointments.*/
public class TimeManager {

    /**
     * This is the generateTimes method.
     * This method generates an hourly time list.
     * @param hour Starting hour.
     * @param maxHour Last hour.
     * @return Returns the list with hourly set intervals.
     */
    public static ObservableList<LocalTime> generateTimes(int hour, int maxHour){

        /** Creates the list schedule.*/
        ObservableList<LocalTime> timeList = FXCollections.observableArrayList();

        /** Establishes a loop to control the schedule. Keep hours from 1 to 23.*/
        for(int i = hour; i < maxHour; i++ ){

            /** Adds an hour to the list.*/
            timeList.add(LocalTime.of(i, 0));
        }

        /** Returns the populated list.*/
        return timeList;
    }
}
