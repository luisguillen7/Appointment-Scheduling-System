package model;

/** This is the Month model class. It defines the variables, setters and getters and a constructor to create month objects. */
public class Month {

    /** Defines variables and their data types for month object attributes.*/
    private String month;
    private int monthID;

    /**
     * This is a constructor for a month object.
     * @param monthID The ID of the month.
     * @param month The name of the month.
     */
    public Month(int monthID, String month) {
        this.month = month;
        this.monthID = monthID;
    }

    /** Overrides the toString method and allows the names of the countries to be displayed */
    public String toString(){
        return (month);
    }

    /**
     * This is the getMonth method.
     * The name of the month.
     * @return Returns the name of the month.
     */
    public String getMonth() {
        return month;
    }

    /**
     * This is the setMonth method.
     * It sets the name of the month.
     * @param month Accepts and sets the name of the month.
     */
    public void setMonth(String month) {
        this.month = month;
    }

    /**
     * This is the getMonthID method.
     * The ID of the month. Example: (January has an ID of 1.)
     * @return Returns the ID of the month.
     */
    public int getMonthID() {
        return monthID;
    }

    /**
     * This is the setMonthID method.
     * It sets the ID of the month.
     * @param monthID Accepts and sets the ID of the month.
     */
    public void setMonthID(int monthID) {
        this.monthID = monthID;
    }
}
