package model;

/** This is the Country model class. It defines the variables, setters and getters and a constructor to create country objects. */
public class Country {

    /** Defines variables and their data types for the country object attributes.*/
    private int countryId;
    private String countryName;

    /**
     * This is the constructor to create country objects.
     * @param countryId The ID of the country.
     * @param countryName The name of the country
     */
    public Country(int countryId, String countryName) {
        this.countryId = countryId;
        this.countryName = countryName;
    }

    /** Overrides the toString method and allows the names of the countries to be displayed */
    public String toString(){
        return (countryName);
    }

    /**
     * This method gets the ID of the country.
     * The ID that uniquely identifies the country.
     * @return Returns the ID of the country.
     */
    public int getCountryId() {
        return countryId;
    }

    /**
     * This method sets the ID of the country.
     * The ID that uniquely identifies the country.
     * @param countryId Accepts and sets the ID of the country.
     */
    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    /**
     * This method gets the name of the country.
     * The name of the country.
     * @return Returns the name of the country.
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * This method sets the name of the country.
     * The name of the country.
     * @param countryName Accepts and sets the name of the country.
     */
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
}
