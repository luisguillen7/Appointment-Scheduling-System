package model;

/** This is the Contact model class. It defines the variables, setters and getters and a constructor to create contact objects. */
public class Contact {

    /** Defines variables and their data types for the contact object attributes.*/
    private int id;
    private String name;

    /**
     * This is the constructor to create contact objects.
     * @param id The ID of the contact.
     * @param name The name of the contact.
     */
    public Contact(int id, String name) {
        this.id = id;
        this.name = name;
    }

    /** Overrides the toString method and allows the names of the contacts to be displayed */
    public String toString(){
        return (name);
    }

    /**
     * This method gets the ID of the user.
     * The ID number uniquely identifies the user.
     * @return Returns the ID of the user.
     */
    public int getId() {
        return id;
    }

    /**
     * This method sets the ID of the user.
     * The ID number uniquely identifies the user.
     * @param id Accepts and sets the ID of the user.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * This method gets the ID of the user.
     * The name of the user.
     * @return Returns the name of the user.
     */
    public String getName() {
        return name;
    }

    /**
     * This method sets the name of the user.
     * The name of the user.
     * @param name Accepts and sets the name of the user.
     */
    public void setName(String name) {
        this.name = name;
    }
}
