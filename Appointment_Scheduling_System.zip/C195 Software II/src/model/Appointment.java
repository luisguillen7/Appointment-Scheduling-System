package model;

import java.time.LocalDateTime;

/** This is the Appointment model class. It defines the variables, setters and getters and a constructor to create Appointment objects. */
public class Appointment {

    /** Defines variables and their data types for the Appointment object attributes.*/
    private int id;
    private String  title;
    private  String description;
    private String location;
    private String type;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private int customerId;
    private int userId;
    private int contactId;

    /**
     * This is the constructor to create Appointment objects.
     * @param id The ID of the appointment.
     * @param title The title of the appointment.
     * @param description The description of the appointment.
     * @param location The location of the appointment.
     * @param type The type of the appointment.
     * @param starDateTime The start date and time of the appointment.
     * @param endDateTime The end date and time of the appointment.
     * @param customerId The ID of the customer.
     * @param userId The ID of the user.
     * @param contactId The ID of the contact.
     */
    public Appointment(int id, String title, String description, String location, String type, LocalDateTime starDateTime, LocalDateTime endDateTime, int customerId, int userId, int contactId) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.location = location;
        this.type = type;
        this.startDate = starDateTime;
        this.endDate = endDateTime;
        this.customerId = customerId;
        this.userId = userId;
        this.contactId = contactId;
    }

    /**
     * This method gets the ID for the appointment.
     * This ID is a number that uniquely identifies an appointment.
     * @return Returns the appointment ID.
     */
    public int getId() {
        return id;
    }

    /**
     * This method sets the ID for the appointment.
     * This ID is a number that uniquely identifies an appointment.
     * @param id Accepts and sets an ID.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * This method gets the title of the appointment.
     * The title of the appointment.
     * @return  Returns the title of the appointment.
     */
    public String getTitle() {
        return title;
    }

    /**
     * This method sets the title of the appointment.
     * The title of the appointment.
     * @param title Accepts and sets a title.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * This method gets the description of the appointment.
     * Describes the purpose of the appointment.
     * @return Returns the description.
     */
    public String getDescription() {
        return description;
    }

    /**
     * This method sets the description of the appointment.
     * Describes the purpose of the appointment.
     * @param description Accepts and sets the description.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * This method gets the location of the appointment.
     * The location of the appointment.
     * @return Returns the location.
     */
    public String getLocation() {
        return location;
    }

    /**
     * This method sets the location of the appointment.
     * The location of the appointment.
     * @param location Accepts and sets the location.
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * This method gets the type of the appointment.
     * The type of the appointment.
     * @return Returns the type.
     */
    public String getType() {
        return type;
    }

    /**
     * This method sets the type of the appointment.
     * The type of the appointment.
     * @param type Accepts and sets the type.
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * This method gets the start date of the appointment.
     * The start date and time of the appointment.
     * @return Returns the start date and time of the appointment.
     */
    public LocalDateTime getStartDate() {
        return startDate;
    }

    /**
     * This method sets the start date and time of the appointment.
     * The start date and time of the appointment.
     * @param startDate Accepts and sets the start date and time.
     */
    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    /**
     * This method gets the end date and time of the appointment.
     * The end date and time of the appointment.
     * @return Returns the end date and time.
     */
    public LocalDateTime getEndDate() {
        return endDate;
    }

    /**
     * This method sets the end date and time of the appointment.
     * The end date and time of the appointment.
     * @param endDate Accepts and sets the end date and time.
     */
    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    /**
     *  This method gets the customer ID of the appointment.
     *  The ID of the customer that has the appointment.
     * @return Returns the ID of the customer.
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * This method sets the customer ID of the appointment.
     * The ID of the customer that has the appointment.
     * @param customerId Accepts and sets the customer ID.
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**
     * This method gets the user ID of the appointment.
     * The ID of the user that booked the appointment.
     * @return Returns the ID of the user.
     */
    public int getUserId() {
        return userId;
    }

    /**
     * This method sets the user ID of the appointment.
     * The ID of the user of the that booked the appointment.
     * @param userId Accepts and sets the user ID.
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * This method gets the contact ID of the appointment.
     * The ID of the contact for the appointment.
     * @return Returns the ID of the contact.
     */
    public int getContactId() {
        return contactId;
    }

    /**
     * This method sets the user ID of the appointment.
     * The ID of the contact for the appointment.
     * @param contactId Accepts and sets the contact ID.
     */
    public void setContactId(int contactId) {
        this.contactId = contactId;
    }
}