package model;

/** This is the Customer model class. It defines the variables, setters and getters and a constructor to create customer objects. */
public class Customer {

    /** Defines variables and their data types for the Customer object attributes.*/
    private int id, country_Id, divisionId;
    private String name;
    private String address;
    private String postalCode;
    private String phone;
    private String firstLevelDivision;
    private String country;


    /**
     * This is a constructor for a Customer object.
     * @param id The ID of the Customer.
     * @param name The name of the Customer.
     * @param address The address of the Customer.
     * @param postalCode The postalCode of the Customer.
     * @param phone The phone of the Customer.
     */
    public Customer(int id, String name, String address, String postalCode, String phone, String firstLevelDivision, String country, int divisionId, int countryId) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.postalCode = postalCode;
        this.phone = phone;
        this.firstLevelDivision = firstLevelDivision;
        this.country = country;
        this.country_Id = countryId;
        this.divisionId = divisionId;
    }

    /** Overrides the toString method and allows the names of the contacts to be displayed */
    public String toString(){
        return (String.valueOf(id));
    }

    /**
     * This method gets the country ID.
     * The country ID where the customer resides.
     * @return Returns the country ID.
     */
    public int getCountryId() {
        return country_Id;
    }

    /**
     * This method sets the country ID.
     * The country ID where the customer resides.
     * @param country_Id Accepts and sets the country ID.
     */
    public void setCountry_Id(int country_Id) {
        this.country_Id = country_Id;
    }

    /**
     * This method gets the first level division ID.
     * The ID of the first level division where the customer resides.
     * @return Returns the division ID.
     */
    public int getDivisionId() {
        return divisionId;
    }

    /**
     * This method sets the first level division ID.
     * The ID of the first level division where the customer resides.
     * @param divisionId Accepts and sets the division ID.
     */
    public void setDivisionId(int divisionId) {
        this.divisionId = divisionId;
    }

    /**
     * This method gets the customer ID.
     * The ID that uniquely identifies the customer.
     * @return Returns the customer ID.
     */
    public int getId() {
        return id;
    }

    /**
     * This method sets the customer ID.
     * The ID the uniquely identifies the customer.
     * @param id Accepts and sets the customer ID.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * This method gets the name of the customer.
     * The name of the customer.
     * @return Returns the name of the customer.
     */
    public String getName() {
        return name;
    }

    /**
     * This method sets the name of the customer.
     * The name of the customer.
     * @param name Accepts and sets the name of the customer.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * This method gets the address of the customer.
     * The address where the customer resides.
     * @return Returns the address of the customer.
     */
    public String getAddress() {
        return address;
    }

    /**
     * This method sets the address of the customer.
     * The address where the customer resides.
     * @param address Accepts and sets the customer's address.
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * This method gets the postal code of the customer.
     * The postal code where the customer resides.
     * @return Returns the postal code of the customer.
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * This method sets the postal code of the customer.
     * The postal code where the customer resides.
     * @param postalCode Accepts and sets the postal code of the customer.
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /**
     * This method gets the phone number of the customer.
     * The phone number of the customer.
     * @return Returns the phone number of the customer.
     */
    public String getPhone() {
        return phone;
    }

    /**
     * This method sets the phone number of the customer.
     * The phone number of the customer.
     * @param phone Accepts and sets the phone number of the customer.
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * This method gets the name of the  first level division.
     * The name of the first level division.
     * @return Returns the name of the first level division.
     */
    public String getFirstLevelDivision(){
        return firstLevelDivision;
    }

    /**
     * This method sets the name of the first level division.
     * The name of the first level division.
     * @param firstLevelDivision Accepts and sets the name of the first level division.
     */
    public void setFirstLevelDivision(String firstLevelDivision){
        this.firstLevelDivision = firstLevelDivision;
    }

    /**
     * This method gets the name of the country.
     * The name of the country.
     * @return Returns the name of the country.
     */
    public String getCountry(){
        return country;
    }

    /**
     * This method sets the name of the country.
     * The name of the country.
     * @param country Accepts and sets the name of the country.
     */
    public void setCountry(String country){
        this.country = country;
    }
}
