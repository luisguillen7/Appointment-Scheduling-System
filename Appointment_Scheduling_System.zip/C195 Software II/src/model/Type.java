package model;

/** This is the Type model class. It defines the variables, setters and getters and a constructor to create type objects. */
public class Type {

    /** Defines variables and their data types for the type object attributes.*/
    private String type;

    /**
     * This is a constructor for a type object.
     * @param type The name of the type.
     */
    public Type( String type) {
        this.type = type;
    }

    /** Overrides the toString method and allows the names of the countries to be displayed */
    public String toString(){
        return (type);
    }

    /**
     * This is the getType method.
     * The name of the type of appointment.
     * @return Returns the name of the type of appointment.
     */
    public String getType() {
        return type;
    }

    /**
     * This is the setType method.
     * The name of the type of appointment.
     * @param type Accepts and sets a type.
     */
    public void setType(String type) {
        this.type = type;
    }
}
