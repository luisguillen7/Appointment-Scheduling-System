package model;

/** This is the First Level Division model class. It defines the variables, setters and getters and a constructor to create first level division objects. */
public class FirstLevelDivision {

    /** Defines variables and their data types for the First Level Division object attributes.*/
    private int divisionId;
    private String divisionName;
    private int countryId;

    /**
     * This is a constructor for a first level division object.
     * @param divisionId The ID of the first level division.
     * @param divisionName The name of the first level division.
     * @param countryId The ID of the country.
     */
    public FirstLevelDivision(int divisionId, String divisionName, int countryId) {
        this.divisionId = divisionId;
        this.divisionName = divisionName;
        this.countryId = countryId;
    }

    /** Overrides the toString method and allows the names of the first level divisions to be displayed */
    public String toString(){
        return (divisionName);
    }

    /**
     * This method gets the country ID.
     * The country ID.
     * @return Returns the country ID.
     */
    public int getCountryId() {
        return countryId;
    }

    /**
     * This method sets the country ID.
     * The country ID.
     * @param countryId Accepts and sets a country ID.
     */
    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    /**
     * This method gets the first level division ID.
     * The ID of the first level division.
     * @return Returns the first level division ID.
     */
    public int getDivisionId() {
        return divisionId;
    }

    /**
     * This method sets the first level division ID.
     * The ID of the first level division.
     * @param divisionId Accepts and sets a first level division ID.
     */
    public void setDivisionId(int divisionId) {
        this.divisionId = divisionId;
    }

    /**
     * This method gets the first level division name.
     * The name of the first level division.
     * @return Returns the name of the first level division.
     */
    public String getDivisionName() {
        return divisionName;
    }

    /**
     * This method sets the first level division name.
     * The name of the first level division.
     * @param divisionName Accepts and sets the name of the first level division.
     */
    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

}
