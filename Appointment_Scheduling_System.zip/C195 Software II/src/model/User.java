package model;

/** This is the User model class. It defines the variables, setters and getters and a constructor to create user objects. */
public class User {

    /** Defines variables and their data types for the user object attributes.*/
    private int id;
    private String username;
    private String password;


    /**
     * This is a constructor for a user object.
     * @param id The ID of the user.
     * @param name The name of the user.
     * @param password The password of the user.
     */
    public User(int id, String name, String password) {
        this.id = id;
        this.username = name;
        this.password = password;
    }

    /** Overrides the toString method and allows the names of the users to be displayed.*/
    public String toString(){
        return (String.valueOf(id));
    }

    /**
     * This method gets the ID of the user.
     * The ID of the user.
     * @return Returns the ID of the user.
     */
    public int getId() {
        return id;
    }

    /**
     * This method sets the ID of user.
     * The ID of the user.
     * @param id Accepts and sets the ID of a user.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * This method gets the name of the user.
     * The name of the user.
     * @return Returns the name of the user.
     */
    public String getUsername() {
        return username;
    }

    /**
     * The method sets the name of the user.
     * The name of the user.
     * @param name Accepts and sets the name of a user.
     */
    public void setUserName(String name) {
        this.username = name;
    }

    /**
     * This method gets the password of the user.
     * The password that lets the users log into the application.
     * @return Returns the password.
     */
    public String getPassword() {
        return password;
    }

    /**
     * This method sets the password of the user.
     * The password that lets the users log into the application.
     * @param password Accepts and sets a password.
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
