package expressions;

/** This lambda expression displays the zone ID of the user's system.*/
@FunctionalInterface
public interface MyZoneId {

    /**
     * This is the getMyZoneId method.
     * When the method is called, it displays the zone ID.
     * @return Returns the user's zone ID.
     */
    String getMyZoneId();

}
