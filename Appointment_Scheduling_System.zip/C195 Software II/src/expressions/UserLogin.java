package expressions;

import java.time.LocalDateTime;

/** This lambda expression collects the data from the user log-in and is used to write to a file.*/
@FunctionalInterface
public interface UserLogin {

     /**
      * This is the userLogin method.
      * It collects the data from the user log-in.
      * @param username The user's username.
      * @param password The user's password.
      * @param timeStamp The timestamp of the log-in.
      * @param loginStatus To record status of log-in (Successful or Unsuccessful).
      */
     void userLogin(String username, String password, LocalDateTime timeStamp, String loginStatus);

}
